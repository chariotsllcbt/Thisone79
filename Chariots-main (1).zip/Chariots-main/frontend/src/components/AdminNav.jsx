import { Link, useLocation, useNavigate } from "react-router-dom";
import { LogOut, BarChart3, Users, Sliders, ListChecks, ShieldCheck } from "lucide-react";
import { useAuth } from "@/lib/auth";

const ITEMS = [
  { to: "/admin",              label: "Overview",     Icon: BarChart3,    testid: "nav-overview" },
  { to: "/admin/rides",        label: "Rides",        Icon: ListChecks,   testid: "nav-rides" },
  { to: "/admin/applications", label: "Applications", Icon: ShieldCheck,  testid: "nav-applications" },
  { to: "/admin/users",        label: "Users",        Icon: Users,        testid: "nav-users" },
  { to: "/admin/pricing",      label: "Pricing",      Icon: Sliders,      testid: "nav-pricing" },
];

export default function AdminNav() {
  const { user, logout } = useAuth();
  const loc = useLocation();
  const nav = useNavigate();

  return (
    <>
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-zinc-300">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/admin" className="flex items-center gap-2">
            <img src="/chariot-logo.png" alt="Chariot" className="w-8 h-8 object-cover rounded" />
            <span className="font-display-tight font-extrabold text-lg">Chariot</span>
            <span className="overline text-amber-600 ml-2 hidden sm:inline">CONTROL</span>
          </Link>
          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {ITEMS.map(({ to, label, Icon, testid }) => (
              <Link
                key={to}
                to={to}
                data-testid={testid}
                className={`flex items-center gap-2 px-3 py-2 text-sm border-b-2 ${loc.pathname === to ? "border-amber-500 text-zinc-900 font-semibold" : "border-transparent text-zinc-500 hover:text-zinc-900"}`}
              >
                <Icon className="w-4 h-4" /> {label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <div className="text-xs text-right hidden sm:block">
              <div className="font-medium text-zinc-900" data-testid="user-name">{user?.name}</div>
              <div className="text-zinc-500">{user?.email}</div>
            </div>
            <button data-testid="logout-btn" onClick={() => { logout(); nav("/"); }} className="p-2 hover:bg-zinc-100" aria-label="Sign out" title="Sign out">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>
      {/* Mobile bottom nav */}
      <nav className="md:hidden sticky top-16 z-30 bg-white border-b border-zinc-200">
        <div className="max-w-7xl mx-auto px-2 flex">
          {ITEMS.map(({ to, label, Icon, testid }) => (
            <Link
              key={to}
              to={to}
              data-testid={`m-${testid}`}
              className={`flex-1 flex flex-col items-center gap-1 py-2 text-[10px] uppercase tracking-wider border-b-2 ${loc.pathname === to ? "border-amber-500 text-zinc-900 font-semibold" : "border-transparent text-zinc-500"}`}
            >
              <Icon className="w-4 h-4" /> {label}
            </Link>
          ))}
        </div>
      </nav>
    </>
  );
}
