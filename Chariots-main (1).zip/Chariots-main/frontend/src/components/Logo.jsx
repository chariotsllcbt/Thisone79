import { Link } from "react-router-dom";

// Reusable brand logo. Uses the official Chariot square mark from /public.
// When showText is true, we use the entire logo image (icon + chariot wordmark).
// When false, we crop to the icon portion via aspect-square + object-cover.
export default function Logo({ size = 36, showText = true, className = "", to = "/" }) {
  const Inner = (
    <span className={`inline-flex items-center gap-2 ${className}`}>
      <img
        src="/chariot-logo.png"
        alt="Chariot"
        style={{ width: size, height: size }}
        className="object-cover rounded-md"
      />
      {showText && (
        <span className="font-display-tight font-extrabold text-xl tracking-tight">Chariot</span>
      )}
    </span>
  );
  return to ? <Link to={to} className="inline-flex">{Inner}</Link> : Inner;
}
