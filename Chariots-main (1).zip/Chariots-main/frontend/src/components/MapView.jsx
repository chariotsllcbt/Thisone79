import { useEffect } from "react";
import { MapContainer, TileLayer, Marker, useMap, useMapEvents, Polyline, Circle } from "react-leaflet";
import L from "leaflet";

// Chariot service area: Portland OR + Vancouver WA metro (30-mile radius from downtown PDX)
export const SERVICE_AREA = {
  center: { lat: 45.5152, lng: -122.6784 },
  radiusMiles: 30,
  radiusMeters: 30 * 1609.344,
};

export function haversineMiles(lat1, lng1, lat2, lng2) {
  const R = 3958.8;
  const toRad = (d) => (d * Math.PI) / 180;
  const dlat = toRad(lat2 - lat1);
  const dlng = toRad(lng2 - lng1);
  const a = Math.sin(dlat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dlng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function isInServiceArea(lat, lng) {
  return haversineMiles(lat, lng, SERVICE_AREA.center.lat, SERVICE_AREA.center.lng) <= SERVICE_AREA.radiusMiles;
}

// Fix default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
});

const pickupIcon = L.divIcon({
  className: "",
  html: `<div style="width:18px;height:18px;background:#0055FF;border:3px solid white;border-radius:50%;box-shadow:0 0 0 2px #0055FF"></div>`,
  iconSize: [18, 18],
  iconAnchor: [9, 9],
});

const dropoffIcon = L.divIcon({
  className: "",
  html: `<div style="width:18px;height:18px;background:#09090b;border:3px solid white;border-radius:2px;box-shadow:0 0 0 2px #09090b"></div>`,
  iconSize: [18, 18],
  iconAnchor: [9, 9],
});

function Recenter({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}

function ClickHandler({ onClick }) {
  useMapEvents({
    click: (e) => onClick && onClick({ lat: e.latlng.lat, lng: e.latlng.lng }),
  });
  return null;
}

export default function MapView({ pickup, dropoff, onMapClick, mode = "pickup", className = "", center, showServiceArea = true }) {
  const initialCenter = center || pickup || SERVICE_AREA.center;
  return (
    <div className={`relative overflow-hidden ${className}`}>
      <MapContainer center={[initialCenter.lat, initialCenter.lng]} zoom={11} scrollWheelZoom className="w-full h-full">
        <TileLayer
          attribution='&copy; OpenStreetMap'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <Recenter center={center ? [center.lat, center.lng] : null} />
        {onMapClick && <ClickHandler onClick={onMapClick} />}
        {showServiceArea && (
          <Circle
            center={[SERVICE_AREA.center.lat, SERVICE_AREA.center.lng]}
            radius={SERVICE_AREA.radiusMeters}
            pathOptions={{ color: "#0055FF", weight: 2, fillColor: "#0055FF", fillOpacity: 0.05, dashArray: "6 6" }}
          />
        )}
        {pickup && <Marker position={[pickup.lat, pickup.lng]} icon={pickupIcon} />}
        {dropoff && <Marker position={[dropoff.lat, dropoff.lng]} icon={dropoffIcon} />}
        {pickup && dropoff && (
          <Polyline positions={[[pickup.lat, pickup.lng], [dropoff.lat, dropoff.lng]]} color="#0055FF" weight={3} dashArray="6 6" />
        )}
      </MapContainer>
      {onMapClick && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[1000] bg-white border border-zinc-900 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider pointer-events-none">
          Tap map to set {mode}
        </div>
      )}
    </div>
  );
}
