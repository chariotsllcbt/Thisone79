import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Car, ArrowLeft } from "lucide-react";

export default function AuthShell({ role, accent = "blue", title, kicker, sideImg, dark = false, extraFields = false }) {
  const nav = useNavigate();
  const { login, register } = useAuth();
  const [mode, setMode] = useState("login");
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    email: "", password: "", name: "", phone: "",
    vehicle_make: "", vehicle_model: "", vehicle_plate: "",
  });

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "login") {
        const u = await login(form.email, form.password, role);
        toast.success(`Welcome back, ${u.name}`);
      } else {
        const u = await register({ ...form, role });
        toast.success(`Account created. Welcome, ${u.name}`);
      }
      nav(`/${role}`);
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Authentication failed");
    } finally {
      setBusy(false);
    }
  };

  const onGoogle = () => {
    if (role === "admin") return;
    localStorage.setItem("sr_google_role", role);
    const redirect = `${window.location.origin}/auth/callback`;
    window.location.href = `https://auth.emergentagent.com/?redirect=${encodeURIComponent(redirect)}`;
  };

  const accentColor = accent === "emerald" ? "#10B981" : accent === "amber" ? "#F59E0B" : "#0055FF";

  return (
    <div className={`min-h-screen flex ${dark ? "bg-black text-white" : "bg-white text-zinc-900"}`}>
      <div className="flex-1 flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-md">
          <Link to="/" className={`inline-flex items-center gap-2 text-xs mb-8 ${dark ? "text-zinc-400 hover:text-white" : "text-zinc-500 hover:text-zinc-900"}`} data-testid="back-home">
            <ArrowLeft className="w-3.5 h-3.5" /> BACK TO HOME
          </Link>
          <div className="flex items-center gap-2 mb-2">
            <img src="/chariot-logo.png" alt="Chariot" className="w-9 h-9 object-cover rounded" />
            <span className="font-display-tight font-extrabold text-xl">Chariot</span>
          </div>
          <div className="overline mb-2" style={{ color: accentColor }}>{kicker}</div>
          <h1 className="font-display-tight text-4xl sm:text-5xl mb-2">{title}</h1>
          <p className={`text-sm mb-8 ${dark ? "text-zinc-400" : "text-zinc-500"}`}>
            {mode === "login" ? "Sign in to continue." : "Create your account to get started."}
          </p>

          <form onSubmit={submit} className="space-y-4">
            {mode === "register" && (
              <div>
                <label className="overline block mb-1">Full name</label>
                <Input data-testid="name-input" required value={form.name} onChange={set("name")} className={dark ? "bg-zinc-900 border-zinc-800 text-white" : ""} />
              </div>
            )}
            <div>
              <label className="overline block mb-1">Email</label>
              <Input data-testid="email-input" type="email" required value={form.email} onChange={set("email")} className={dark ? "bg-zinc-900 border-zinc-800 text-white" : ""} />
            </div>
            <div>
              <label className="overline block mb-1">Password</label>
              <Input data-testid="password-input" type="password" required value={form.password} onChange={set("password")} className={dark ? "bg-zinc-900 border-zinc-800 text-white" : ""} />
            </div>
            {mode === "register" && extraFields && (
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="overline block mb-1">Phone</label>
                  <Input data-testid="phone-input" value={form.phone} onChange={set("phone")} className={dark ? "bg-zinc-900 border-zinc-800 text-white" : ""} />
                </div>
                <div>
                  <label className="overline block mb-1">Make</label>
                  <Input data-testid="vehicle-make" value={form.vehicle_make} onChange={set("vehicle_make")} placeholder="Toyota" className={dark ? "bg-zinc-900 border-zinc-800 text-white" : ""} />
                </div>
                <div>
                  <label className="overline block mb-1">Model</label>
                  <Input data-testid="vehicle-model" value={form.vehicle_model} onChange={set("vehicle_model")} placeholder="Camry" className={dark ? "bg-zinc-900 border-zinc-800 text-white" : ""} />
                </div>
                <div className="col-span-2">
                  <label className="overline block mb-1">License plate</label>
                  <Input data-testid="vehicle-plate" value={form.vehicle_plate} onChange={set("vehicle_plate")} placeholder="ABC-1234" className={dark ? "bg-zinc-900 border-zinc-800 text-white" : ""} />
                </div>
              </div>
            )}
            {mode === "register" && !extraFields && (
              <div>
                <label className="overline block mb-1">Phone (optional)</label>
                <Input data-testid="phone-input" value={form.phone} onChange={set("phone")} className={dark ? "bg-zinc-900 border-zinc-800 text-white" : ""} />
              </div>
            )}
            <Button data-testid="submit-auth" type="submit" disabled={busy} className="w-full rounded-none h-12 text-base font-semibold" style={{ background: accentColor, color: dark && accent === "emerald" ? "#000" : "#fff" }}>
              {busy ? "Please wait..." : mode === "login" ? "Sign in" : "Create account"}
            </Button>
          </form>

          {role !== "admin" && (
            <>
              <div className={`my-6 flex items-center gap-3 text-xs ${dark ? "text-zinc-500" : "text-zinc-400"}`}>
                <div className={`flex-1 h-px ${dark ? "bg-zinc-800" : "bg-zinc-200"}`} />
                OR
                <div className={`flex-1 h-px ${dark ? "bg-zinc-800" : "bg-zinc-200"}`} />
              </div>
              <button data-testid="google-signin" onClick={onGoogle} className={`w-full h-12 border ${dark ? "border-zinc-800 hover:bg-zinc-900" : "border-zinc-300 hover:bg-zinc-50"} flex items-center justify-center gap-2 font-medium text-sm`}>
                <svg className="w-4 h-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                Continue with Google
              </button>
            </>
          )}

          <p className={`text-sm mt-6 text-center ${dark ? "text-zinc-400" : "text-zinc-600"}`}>
            {mode === "login" ? "Don't have an account? " : "Already have an account? "}
            <button data-testid="toggle-mode" type="button" onClick={() => setMode(mode === "login" ? "register" : "login")} className="font-semibold underline" style={{ color: accentColor }}>
              {mode === "login" ? "Create one" : "Sign in"}
            </button>
          </p>
        </div>
      </div>

      {sideImg && (
        <div className="hidden lg:block flex-1 relative overflow-hidden">
          <img src={sideImg} alt="bg" className="w-full h-full object-cover" />
          <div className={`absolute inset-0 ${dark ? "bg-black/40" : "bg-white/10"}`} />
        </div>
      )}
    </div>
  );
}
