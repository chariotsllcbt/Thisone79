import { Link, useLocation, useNavigate } from "react-router-dom";
import { Car, LogOut, DollarSign, ListChecks, Gauge } from "lucide-react";
import { useAuth } from "@/lib/auth";

export default function DriverNav() {
  const { user, logout } = useAuth();
  const loc = useLocation();
  const nav = useNavigate();
  const item = (to, label, Icon, testid) => (
    <Link to={to} data-testid={testid} className={`flex items-center gap-2 px-3 py-2 text-sm border-b-2 ${loc.pathname === to ? "border-emerald-400 text-white font-semibold" : "border-transparent text-zinc-400 hover:text-white"}`}>
      <Icon className="w-4 h-4" /> {label}
    </Link>
  );
  return (
    <header className="sticky top-0 z-40 backdrop-blur-xl bg-black/70 border-b border-zinc-800 text-white">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/driver" className="flex items-center gap-2">
          <img src="/chariot-logo.png" alt="Chariot" className="w-8 h-8 object-cover rounded" />
          <span className="font-display-tight font-extrabold text-lg">Chariot</span>
          <span className="overline text-emerald-300 ml-2">DRIVER</span>
        </Link>
        <nav className="hidden sm:flex items-center gap-1">
          {item("/driver", "Dispatch", Gauge, "nav-dispatch")}
          {item("/driver/trips", "Trips", ListChecks, "nav-trips")}
          {item("/driver/earnings", "Earnings", DollarSign, "nav-earnings")}
        </nav>
        <div className="flex items-center gap-3">
          <div className="text-xs text-right hidden sm:block">
            <div className="font-medium text-white" data-testid="user-name">{user?.name}</div>
            <div className="text-zinc-400">{user?.email}</div>
          </div>
          <button data-testid="logout-btn" onClick={() => { logout(); nav("/"); }} className="p-2 hover:bg-zinc-800">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
