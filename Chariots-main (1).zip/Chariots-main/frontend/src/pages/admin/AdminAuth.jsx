import AuthShell from "@/components/AuthShell";

const SIDE = "https://static.prod-images.emergentagent.com/jobs/f6827839-cd51-4ed1-976b-103c6c41792f/images/aa8844bb8e4c44edc7789923f2d4e47f7840d6b438e47711e2a3024fe446cecc.png";

export default function AdminAuth() {
  return <AuthShell role="admin" accent="amber" kicker="CONTROL ROOM" title="Run the platform." sideImg={SIDE} />;
}
