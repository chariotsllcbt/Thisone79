import { useEffect, useState } from "react";
import AdminNav from "@/components/AdminNav";
import api from "@/lib/api";
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, LineChart, Line } from "recharts";
import { Car, DollarSign, Users, Activity } from "lucide-react";

const Kpi = ({ icon: Icon, label, value, sub, testid }) => (
  <div className="border border-zinc-300 p-5 bg-white" data-testid={testid}>
    <div className="flex items-center justify-between">
      <div className="overline text-zinc-500">{label}</div>
      <Icon className="w-4 h-4 text-zinc-400" />
    </div>
    <div className="font-display-tight text-4xl mt-2">{value}</div>
    {sub && <div className="text-xs text-zinc-500 mt-1">{sub}</div>}
  </div>
);

export default function AdminDashboard() {
  const [s, setS] = useState(null);
  const [sms, setSms] = useState(null);

  useEffect(() => {
    const load = () => api.get("/admin/stats").then(({ data }) => setS(data));
    load();
    api.get("/admin/sms-status").then(({ data }) => setSms(data)).catch(() => {});
    const t = setInterval(load, 8000);
    return () => clearInterval(t);
  }, []);

  if (!s) return <div className="min-h-screen bg-white"><AdminNav /><div className="p-6 text-zinc-500">Loading...</div></div>;

  return (
    <div className="min-h-screen bg-zinc-50">
      <AdminNav />
      <div className="max-w-7xl mx-auto p-4 sm:p-6">
        <div className="flex items-end justify-between mb-6 flex-wrap gap-4">
          <div>
            <div className="overline text-amber-600">CONTROL ROOM</div>
            <h1 className="font-display-tight text-4xl">Platform overview</h1>
          </div>
          <div className="text-xs text-zinc-500">Auto-refreshes every 8 seconds</div>
        </div>

        {sms && !sms.configured && (
          <div className="mb-6 border border-amber-300 bg-amber-50 px-4 py-3 text-sm flex items-start gap-3" data-testid="sms-dormant-banner">
            <span className="mt-0.5 inline-flex items-center justify-center w-5 h-5 bg-amber-500 text-white text-xs font-bold">!</span>
            <div className="text-zinc-700">
              <span className="font-semibold text-zinc-900">SMS notifications are dormant.</span> Add <code className="px-1 bg-amber-100">TWILIO_ACCOUNT_SID</code>, <code className="px-1 bg-amber-100">TWILIO_AUTH_TOKEN</code>, and <code className="px-1 bg-amber-100">TWILIO_FROM_NUMBER</code> to <code className="px-1 bg-amber-100">backend/.env</code> and restart the backend to enable customer &amp; driver SMS alerts.
            </div>
          </div>
        )}
        {sms && sms.configured && (
          <div className="mb-6 border border-emerald-300 bg-emerald-50 px-4 py-3 text-sm flex items-center gap-3" data-testid="sms-configured-banner">
            <span className="inline-block w-2 h-2 bg-emerald-500 rounded-full pulse-dot" />
            <span className="text-zinc-700"><span className="font-semibold text-zinc-900">SMS notifications active</span> · sending from <code className="px-1 bg-emerald-100">{sms.from_number}</code></span>
          </div>
        )}

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-zinc-300 mb-6">
          <Kpi icon={Car} label="TOTAL RIDES" value={s.total_rides} sub={`${s.completed_rides} completed`} testid="kpi-rides" />
          <Kpi icon={DollarSign} label="GROSS REVENUE" value={`$${s.total_revenue.toFixed(2)}`} sub="all-time bookings" testid="kpi-revenue" />
          <Kpi icon={DollarSign} label="PLATFORM FEE (15%)" value={`$${s.platform_revenue.toFixed(2)}`} sub="company earnings" testid="kpi-platform" />
          <Kpi icon={Activity} label="ACTIVE DRIVERS" value={s.active_drivers} sub={`${s.total_drivers} total registered`} testid="kpi-active-drivers" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
          <div className="bg-white border border-zinc-300 p-5">
            <div className="overline text-zinc-500 mb-2">REVENUE — LAST 7 DAYS</div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <BarChart data={s.daily}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="revenue" fill="#0055FF" />
                  <Bar dataKey="platform" fill="#F59E0B" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="bg-white border border-zinc-300 p-5">
            <div className="overline text-zinc-500 mb-2">RIDES PER DAY</div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <LineChart data={s.daily}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="rides" stroke="#0055FF" strokeWidth={2.5} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-px bg-zinc-300">
          <div className="bg-white p-5">
            <div className="overline text-zinc-500">CUSTOMERS</div>
            <div className="font-display-tight text-4xl mt-1 flex items-center gap-2"><Users className="w-6 h-6 text-zinc-400" /> {s.total_customers}</div>
          </div>
          <div className="bg-white p-5">
            <div className="overline text-zinc-500">DRIVERS</div>
            <div className="font-display-tight text-4xl mt-1 flex items-center gap-2"><Users className="w-6 h-6 text-zinc-400" /> {s.total_drivers}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
