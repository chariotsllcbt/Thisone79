import { useEffect, useState } from "react";
import AdminNav from "@/components/AdminNav";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { ShieldCheck, ShieldX, Hourglass, Car as CarIcon, Phone, Mail, IdCard, Calendar } from "lucide-react";

const STATUS_FILTERS = [
  { k: "pending_review", label: "Pending" },
  { k: "approved",       label: "Approved" },
  { k: "rejected",       label: "Rejected" },
  { k: "all",            label: "All" },
];

const STATUS_META = {
  pending_review: { label: "Pending review", cls: "bg-amber-100 text-amber-800",  Icon: Hourglass },
  approved:       { label: "Approved",       cls: "bg-emerald-100 text-emerald-700", Icon: ShieldCheck },
  rejected:       { label: "Rejected",       cls: "bg-red-100 text-red-700",       Icon: ShieldX },
  incomplete:     { label: "Incomplete",     cls: "bg-blue-100 text-blue-700",     Icon: Hourglass },
};

export default function AdminDriverApplications() {
  const [status, setStatus] = useState("pending_review");
  const [apps, setApps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [decisionFor, setDecisionFor] = useState(null); // {app, kind: 'approve'|'reject'}
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/admin/driver-applications?status=${status}`);
      setApps(data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [status]);

  const decide = async () => {
    if (!decisionFor) return;
    setBusy(true);
    try {
      const path = decisionFor.kind === "approve"
        ? `/admin/drivers/${decisionFor.app.id}/approve`
        : `/admin/drivers/${decisionFor.app.id}/reject`;
      await api.post(path, { reason });
      toast.success(decisionFor.kind === "approve" ? "Driver approved" : "Driver rejected");
      setDecisionFor(null); setReason(""); load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Failed");
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen bg-zinc-50">
      <AdminNav />
      <div className="max-w-7xl mx-auto p-4 sm:p-6">
        <div className="overline text-amber-600">DRIVER APPLICATIONS</div>
        <h1 className="font-display-tight text-4xl mb-2">Vet new drivers</h1>
        <p className="text-sm text-zinc-500 mb-6">Review each applicant's Uber/Lyft attestation and background-check info before approving them to drive.</p>

        <div className="flex items-center gap-1 border border-zinc-200 p-0.5 mb-4 bg-white inline-flex">
          {STATUS_FILTERS.map((f) => (
            <button
              key={f.k}
              data-testid={`app-filter-${f.k}`}
              onClick={() => setStatus(f.k)}
              className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold ${status === f.k ? "bg-zinc-900 text-white" : "text-zinc-600 hover:bg-zinc-100"}`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="p-12 text-center text-zinc-500">Loading applications...</div>
        ) : apps.length === 0 ? (
          <div className="bg-white border border-zinc-300 p-16 text-center" data-testid="empty-applications">
            <ShieldCheck className="w-12 h-12 text-zinc-300 mx-auto mb-3" />
            <div className="font-display-tight text-2xl mb-1">No {STATUS_FILTERS.find(f => f.k === status)?.label.toLowerCase()} applications</div>
            <div className="text-sm text-zinc-500">Driver applications will appear here when new drivers apply.</div>
          </div>
        ) : (
          <div className="space-y-3">
            {apps.map((a) => {
              const meta = STATUS_META[a.application_status] || STATUS_META.pending_review;
              const StatusIcon = meta.Icon;
              return (
                <div key={a.id} data-testid={`application-${a.id}`} className="bg-white border border-zinc-300 hover:border-amber-500 transition-colors">
                  <div className="p-5 grid grid-cols-1 lg:grid-cols-12 gap-4">
                    {/* Identity */}
                    <div className="lg:col-span-3">
                      <div className="overline text-zinc-500">APPLICANT</div>
                      <div className="font-display-tight text-xl mt-1">{a.name}</div>
                      <div className="flex items-center gap-1.5 text-xs text-zinc-600 mt-2"><Mail className="w-3 h-3" /> {a.email}</div>
                      <div className="flex items-center gap-1.5 text-xs text-zinc-600 mt-1"><Phone className="w-3 h-3" /> {a.phone || "—"}</div>
                      <div className="flex items-center gap-1.5 text-xs text-zinc-500 mt-1"><Calendar className="w-3 h-3" /> Applied {new Date(a.applied_at).toLocaleDateString()}</div>
                    </div>

                    {/* Eligibility */}
                    <div className="lg:col-span-3">
                      <div className="overline text-zinc-500">UBER / LYFT ATTESTATION</div>
                      <div className="flex gap-2 mt-2">
                        {(a.current_platforms || []).length === 0 ? (
                          <span className="text-xs text-red-600">⚠ No platform selected</span>
                        ) : (a.current_platforms || []).map(p => (
                          <span key={p} className={`px-2 py-1 text-xs font-bold uppercase ${p === "uber" ? "bg-zinc-900 text-white" : "bg-pink-500 text-white"}`}>{p}</span>
                        ))}
                      </div>
                      <div className="text-xs text-zinc-500 mt-2">Driver ID</div>
                      <div className="font-mono text-sm">{a.platform_driver_id || "—"}</div>
                    </div>

                    {/* Background */}
                    <div className="lg:col-span-3">
                      <div className="overline text-zinc-500">BACKGROUND CHECK</div>
                      <div className="text-xs text-zinc-500 mt-2 flex items-center gap-1.5"><IdCard className="w-3 h-3" /> License</div>
                      <div className="font-mono text-sm">{a.drivers_license_number || "—"} <span className="text-zinc-500">· {a.drivers_license_state || "—"}</span></div>
                      <div className="text-xs text-zinc-500 mt-1.5">DOB</div>
                      <div className="text-sm">{a.date_of_birth || "—"}</div>
                      <div className="text-xs text-zinc-500 mt-1.5">Consent at</div>
                      <div className="text-xs">{a.background_check_consent_at ? new Date(a.background_check_consent_at).toLocaleString() : "—"}</div>
                    </div>

                    {/* Vehicle + status */}
                    <div className="lg:col-span-3">
                      <div className="overline text-zinc-500">VEHICLE</div>
                      <div className="flex items-center gap-1.5 text-sm mt-2"><CarIcon className="w-4 h-4 text-amber-600" /> {a.vehicle_make} {a.vehicle_model}</div>
                      <div className="font-mono text-xs text-zinc-600 mt-1">{a.vehicle_plate}</div>
                      <div className="mt-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold ${meta.cls}`}>
                          <StatusIcon className="w-3 h-3" /> {meta.label}
                        </span>
                      </div>
                      {a.application_status === "rejected" && a.rejection_reason && (
                        <div className="mt-2 text-xs text-red-700 bg-red-50 border border-red-200 px-2 py-1">
                          <span className="font-semibold">Reason:</span> {a.rejection_reason}
                        </div>
                      )}
                    </div>
                  </div>

                  {a.application_status === "pending_review" && (
                    <div className="border-t border-zinc-200 p-3 bg-zinc-50 flex items-center justify-end gap-2">
                      <Button
                        data-testid={`reject-${a.id}`}
                        variant="outline"
                        onClick={() => { setDecisionFor({ app: a, kind: "reject" }); setReason(""); }}
                        className="rounded-none border-red-300 text-red-700 hover:bg-red-50 hover:text-red-800"
                      >
                        <ShieldX className="w-4 h-4 mr-2" /> Reject
                      </Button>
                      <Button
                        data-testid={`approve-${a.id}`}
                        onClick={() => { setDecisionFor({ app: a, kind: "approve" }); setReason(""); }}
                        className="rounded-none bg-emerald-600 hover:bg-emerald-700"
                      >
                        <ShieldCheck className="w-4 h-4 mr-2" /> Approve to drive
                      </Button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <AlertDialog open={!!decisionFor} onOpenChange={(o) => !o && setDecisionFor(null)}>
        <AlertDialogContent className="rounded-none">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display-tight text-2xl">
              {decisionFor?.kind === "approve" ? "Approve this driver?" : "Reject this application?"}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-sm">
              {decisionFor?.kind === "approve"
                ? <>Marking <span className="font-semibold text-zinc-900">{decisionFor?.app.name}</span> as background-check clear and granting them permission to go online and accept rides. They'll get an SMS confirmation.</>
                : <>Block <span className="font-semibold text-zinc-900">{decisionFor?.app.name}</span> from driving. They'll receive an SMS with the reason.</>}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {decisionFor?.kind === "reject" && (
            <div className="mt-2">
              <label className="overline block mb-1 text-zinc-600">Reason (shown to applicant)</label>
              <Input
                data-testid="reject-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. Could not verify Uber/Lyft driver status"
                className="rounded-none"
              />
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="cancel-decision" className="rounded-none">Cancel</AlertDialogCancel>
            <AlertDialogAction
              data-testid="confirm-decision"
              onClick={decide}
              disabled={busy}
              className={`rounded-none ${decisionFor?.kind === "approve" ? "bg-emerald-600 hover:bg-emerald-700" : "bg-red-600 hover:bg-red-700"}`}
            >
              {busy ? "Working..." : decisionFor?.kind === "approve" ? "Yes, approve" : "Yes, reject"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
