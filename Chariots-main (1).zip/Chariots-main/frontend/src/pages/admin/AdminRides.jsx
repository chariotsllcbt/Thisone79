import { useEffect, useMemo, useState } from "react";
import AdminNav from "@/components/AdminNav";
import api from "@/lib/api";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Search, MapPin, Navigation, RefreshCw } from "lucide-react";

const STATUS_META = {
  pending:     { label: "Pending",     cls: "bg-amber-100 text-amber-800" },
  accepted:    { label: "Accepted",    cls: "bg-blue-100 text-blue-800" },
  in_progress: { label: "In Progress", cls: "bg-indigo-100 text-indigo-800" },
  completed:   { label: "Completed",   cls: "bg-orange-100 text-orange-800" },
  paid:        { label: "Paid",        cls: "bg-emerald-100 text-emerald-800" },
  cancelled:   { label: "Cancelled",   cls: "bg-zinc-200 text-zinc-600" },
};

const FILTERS = [
  { k: "all",         label: "All" },
  { k: "live",        label: "Live", statuses: ["pending", "accepted", "in_progress"] },
  { k: "completed",   label: "Completed", statuses: ["completed", "paid"] },
  { k: "cancelled",   label: "Cancelled", statuses: ["cancelled"] },
];

export default function AdminRides() {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState(null);

  const load = async () => {
    try {
      const { data } = await api.get("/admin/rides");
      setRides(data);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); const t = setInterval(load, 8000); return () => clearInterval(t); }, []);

  const filtered = useMemo(() => {
    const f = FILTERS.find(x => x.k === filter);
    const lo = q.trim().toLowerCase();
    return rides.filter((r) => {
      if (f?.statuses && !f.statuses.includes(r.status)) return false;
      if (!lo) return true;
      return [r.customer_name, r.driver_name, r.pickup_address, r.dropoff_address]
        .filter(Boolean).some((s) => s.toLowerCase().includes(lo));
    });
  }, [rides, q, filter]);

  const counts = useMemo(() => {
    const out = { all: rides.length };
    FILTERS.forEach((f) => {
      if (f.statuses) out[f.k] = rides.filter((r) => f.statuses.includes(r.status)).length;
    });
    return out;
  }, [rides]);

  return (
    <div className="min-h-screen bg-zinc-50">
      <AdminNav />
      <div className="max-w-7xl mx-auto p-4 sm:p-6">
        <div className="flex flex-wrap items-end justify-between gap-3 mb-6">
          <div>
            <div className="overline text-amber-600">RIDE MONITORING</div>
            <h1 className="font-display-tight text-4xl">All rides</h1>
          </div>
          <button data-testid="refresh-rides" onClick={load} className="inline-flex items-center gap-2 text-xs text-zinc-600 hover:text-zinc-900">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} /> Auto-refresh every 8s
          </button>
        </div>

        <div className="bg-white border border-zinc-300">
          <div className="flex flex-wrap items-center gap-3 p-3 border-b border-zinc-200">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-zinc-400" />
              <Input
                data-testid="ride-search"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search by rider, driver, or address..."
                className="pl-9 rounded-none"
              />
            </div>
            <div className="flex items-center gap-1 border border-zinc-200 p-0.5 flex-wrap">
              {FILTERS.map((f) => (
                <button
                  key={f.k}
                  data-testid={`ride-filter-${f.k}`}
                  onClick={() => setFilter(f.k)}
                  className={`px-3 py-1.5 text-xs uppercase tracking-wider font-semibold ${filter === f.k ? "bg-zinc-900 text-white" : "text-zinc-600 hover:bg-zinc-100"}`}
                >
                  {f.label} · {counts[f.k] ?? 0}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-zinc-100 text-zinc-600 text-xs uppercase tracking-wider">
                <tr>
                  <th className="text-left p-3">When</th>
                  <th className="text-left p-3">Rider</th>
                  <th className="text-left p-3">Driver</th>
                  <th className="text-left p-3">Route</th>
                  <th className="text-right p-3">Dist</th>
                  <th className="text-right p-3">Fare</th>
                  <th className="text-right p-3">Platform</th>
                  <th className="text-left p-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => {
                  const meta = STATUS_META[r.status] || { label: r.status, cls: "bg-zinc-100" };
                  return (
                    <tr
                      key={r.id}
                      data-testid={`adm-ride-${r.id}`}
                      onClick={() => setSelected(r)}
                      className="border-t border-zinc-200 hover:bg-amber-50/40 cursor-pointer"
                    >
                      <td className="p-3 text-xs whitespace-nowrap">{new Date(r.created_at).toLocaleString()}</td>
                      <td className="p-3">{r.customer_name}</td>
                      <td className="p-3">{r.driver_name || <span className="text-zinc-400">—</span>}</td>
                      <td className="p-3 text-xs max-w-[280px]">
                        <div className="truncate">{r.pickup_address}</div>
                        <div className="truncate text-zinc-500">→ {r.dropoff_address}</div>
                      </td>
                      <td className="p-3 text-right whitespace-nowrap">{r.distance_miles} mi</td>
                      <td className="p-3 text-right font-semibold whitespace-nowrap">${r.fare.toFixed(2)}</td>
                      <td className="p-3 text-right text-amber-700 whitespace-nowrap">${r.platform_fee.toFixed(2)}</td>
                      <td className="p-3"><span className={`inline-block px-2 py-0.5 text-xs font-semibold ${meta.cls}`}>{meta.label}</span></td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr><td colSpan={8} className="p-12 text-center text-zinc-500">
                    {rides.length === 0 ? "No rides yet." : "No rides match your filter."}
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Ride details dialog */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="rounded-none max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display-tight text-2xl">Ride details</DialogTitle>
            <DialogDescription className="sr-only">Full details for the selected ride.</DialogDescription>
          </DialogHeader>
          {selected && (
            <div className="space-y-4 text-sm">
              <div className="flex items-start justify-between border-b border-zinc-200 pb-3">
                <div>
                  <div className="overline text-zinc-500">RIDE ID</div>
                  <div className="font-mono text-xs">{selected.id}</div>
                </div>
                <span className={`inline-block px-2 py-0.5 text-xs font-semibold ${STATUS_META[selected.status]?.cls || "bg-zinc-100"}`}>
                  {STATUS_META[selected.status]?.label || selected.status}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><div className="overline text-zinc-500">RIDER</div><div className="font-medium">{selected.customer_name}</div></div>
                <div><div className="overline text-zinc-500">DRIVER</div><div className="font-medium">{selected.driver_name || "—"}</div></div>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-start gap-2"><MapPin className="w-4 h-4 mt-0.5 text-[#0055FF] shrink-0" /> {selected.pickup_address}</div>
                <div className="flex items-start gap-2"><Navigation className="w-4 h-4 mt-0.5 text-zinc-900 shrink-0" /> {selected.dropoff_address}</div>
              </div>
              <div className="grid grid-cols-4 gap-3 border-t border-zinc-200 pt-3">
                <div><div className="overline text-zinc-500">DIST</div><div className="font-semibold">{selected.distance_miles} mi</div></div>
                <div><div className="overline text-zinc-500">TIME</div><div className="font-semibold">{Math.round(selected.duration_minutes)} m</div></div>
                <div><div className="overline text-zinc-500">FARE</div><div className="font-semibold">${selected.fare.toFixed(2)}</div></div>
                <div><div className="overline text-amber-600">15%</div><div className="font-semibold text-amber-700">${selected.platform_fee.toFixed(2)}</div></div>
              </div>
              <div className="grid grid-cols-2 gap-3 border-t border-zinc-200 pt-3">
                <div><div className="overline text-zinc-500">DRIVER EARNED (85%)</div><div className="font-display-tight text-2xl">${selected.driver_earnings.toFixed(2)}</div></div>
                <div><div className="overline text-zinc-500">PAYMENT</div><div className="font-semibold capitalize">{selected.payment_status}</div></div>
              </div>
              {selected.rating && (
                <div className="border-t border-zinc-200 pt-3">
                  <div className="overline text-zinc-500">RIDER RATING</div>
                  <div className="font-semibold">{"★".repeat(selected.rating)}{"☆".repeat(5 - selected.rating)} {selected.review && <span className="text-zinc-500 italic ml-2">"{selected.review}"</span>}</div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
