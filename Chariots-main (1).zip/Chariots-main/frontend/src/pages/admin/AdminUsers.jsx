import { useEffect, useMemo, useState } from "react";
import AdminNav from "@/components/AdminNav";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { Search, ChevronDown, ChevronRight, Car as CarIcon, ShieldOff, ShieldCheck } from "lucide-react";

function Row({ u, expanded, onExpand, onToggle }) {
  const isDriver = u.role === "driver";
  const hasVehicle = isDriver && (u.vehicle_make || u.vehicle_model || u.vehicle_plate);
  return (
    <>
      <tr className="border-t border-zinc-200 hover:bg-zinc-50" data-testid={`user-${u.id}`}>
        <td className="p-3">
          {isDriver ? (
            <button onClick={() => onExpand(u.id)} className="flex items-center gap-1 hover:text-amber-600" data-testid={`expand-${u.id}`}>
              {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
              <span className="font-medium">{u.name}</span>
              {u.online && <span className="ml-1 w-1.5 h-1.5 bg-emerald-500 rounded-full pulse-dot inline-block" title="Online now" />}
            </button>
          ) : (
            <span className="font-medium">{u.name}</span>
          )}
        </td>
        <td className="p-3 text-zinc-600">{u.email}</td>
        <td className="p-3 text-zinc-500 text-xs">{u.phone || <span className="text-zinc-300">—</span>}</td>
        <td className="p-3 text-zinc-500 text-xs">{new Date(u.created_at).toLocaleDateString()}</td>
        <td className="p-3">
          {u.suspended
            ? <span className="bg-red-100 text-red-700 px-2 py-0.5 text-xs font-semibold">SUSPENDED</span>
            : <span className="bg-emerald-100 text-emerald-700 px-2 py-0.5 text-xs font-semibold">ACTIVE</span>}
        </td>
        <td className="p-3 text-right">
          <Button
            data-testid={`toggle-${u.id}`}
            size="sm"
            variant={u.suspended ? "default" : "outline"}
            onClick={() => onToggle(u)}
            className="rounded-none"
          >
            {u.suspended ? <><ShieldCheck className="w-3.5 h-3.5 mr-1" /> Reinstate</> : <><ShieldOff className="w-3.5 h-3.5 mr-1" /> Suspend</>}
          </Button>
        </td>
      </tr>
      {isDriver && expanded && (
        <tr className="border-t border-zinc-100 bg-zinc-50/60">
          <td colSpan={6} className="px-12 py-4">
            {hasVehicle ? (
              <div className="flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2 text-zinc-600"><CarIcon className="w-4 h-4 text-amber-600" /> Vehicle</div>
                <div><span className="overline text-zinc-400 mr-2">MAKE</span><span className="font-medium">{u.vehicle_make || "—"}</span></div>
                <div><span className="overline text-zinc-400 mr-2">MODEL</span><span className="font-medium">{u.vehicle_model || "—"}</span></div>
                <div><span className="overline text-zinc-400 mr-2">PLATE</span><span className="font-mono font-medium">{u.vehicle_plate || "—"}</span></div>
                <div className="ml-auto text-xs">{u.online ? <span className="text-emerald-600 font-semibold">● Online</span> : <span className="text-zinc-400">○ Offline</span>}</div>
              </div>
            ) : (
              <div className="text-sm text-zinc-500">No vehicle info on file.</div>
            )}
          </td>
        </tr>
      )}
    </>
  );
}

function FilterableTable({ users, onToggle }) {
  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [expanded, setExpanded] = useState(null);

  const filtered = useMemo(() => {
    const lo = q.trim().toLowerCase();
    return users.filter((u) => {
      const matchesQ = !lo || u.name?.toLowerCase().includes(lo) || u.email?.toLowerCase().includes(lo) || (u.phone || "").toLowerCase().includes(lo);
      const matchesStatus = statusFilter === "all" || (statusFilter === "suspended" ? u.suspended : !u.suspended);
      return matchesQ && matchesStatus;
    });
  }, [users, q, statusFilter]);

  const counts = useMemo(() => ({
    all: users.length,
    active: users.filter((u) => !u.suspended).length,
    suspended: users.filter((u) => u.suspended).length,
  }), [users]);

  return (
    <div>
      <div className="flex flex-wrap items-center gap-3 p-3 border-b border-zinc-200">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-zinc-400" />
          <Input
            data-testid="user-search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search by name, email, or phone..."
            className="pl-9 rounded-none"
          />
        </div>
        <div className="flex items-center gap-1 border border-zinc-200 p-0.5">
          {["all", "active", "suspended"].map((k) => (
            <button
              key={k}
              data-testid={`filter-${k}`}
              onClick={() => setStatusFilter(k)}
              className={`px-3 py-1.5 text-xs uppercase tracking-wider font-semibold ${statusFilter === k ? "bg-zinc-900 text-white" : "text-zinc-600 hover:bg-zinc-100"}`}
            >
              {k} · {counts[k]}
            </button>
          ))}
        </div>
      </div>
      {filtered.length === 0 ? (
        <div className="p-12 text-center text-zinc-500">No users match your filters.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-zinc-100 text-zinc-600 text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left p-3">Name</th>
                <th className="text-left p-3">Email</th>
                <th className="text-left p-3">Phone</th>
                <th className="text-left p-3">Joined</th>
                <th className="text-left p-3">Status</th>
                <th className="text-right p-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <Row
                  key={u.id}
                  u={u}
                  expanded={expanded === u.id}
                  onExpand={(id) => setExpanded(expanded === id ? null : id)}
                  onToggle={onToggle}
                />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function AdminUsers() {
  const [customers, setCustomers] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [pending, setPending] = useState(null); // {user, nextSuspended}
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const [c, d] = await Promise.all([
      api.get("/admin/users?role=customer"),
      api.get("/admin/users?role=driver"),
    ]);
    setCustomers(c.data);
    setDrivers(d.data);
  };

  useEffect(() => { load(); }, []);

  const requestToggle = (u) => setPending({ user: u, nextSuspended: !u.suspended });

  const confirmToggle = async () => {
    if (!pending) return;
    setBusy(true);
    try {
      await api.patch(`/admin/users/${pending.user.id}/suspend`, { suspended: pending.nextSuspended });
      toast.success(pending.nextSuspended ? "Account suspended" : "Account reinstated");
      setPending(null);
      load();
    } catch {
      toast.error("Failed to update account");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50">
      <AdminNav />
      <div className="max-w-6xl mx-auto p-4 sm:p-6">
        <div className="overline text-amber-600">USER MANAGEMENT</div>
        <h1 className="font-display-tight text-4xl mb-2">People</h1>
        <p className="text-sm text-zinc-500 mb-6">Search, filter, and moderate riders & drivers. Click any driver to view their vehicle.</p>

        <Tabs defaultValue="customers">
          <TabsList className="rounded-none">
            <TabsTrigger value="customers" data-testid="tab-customers" className="rounded-none">Riders · {customers.length}</TabsTrigger>
            <TabsTrigger value="drivers" data-testid="tab-drivers" className="rounded-none">Drivers · {drivers.length}</TabsTrigger>
          </TabsList>
          <TabsContent value="customers" className="bg-white border border-zinc-300 mt-2">
            <FilterableTable users={customers} onToggle={requestToggle} />
          </TabsContent>
          <TabsContent value="drivers" className="bg-white border border-zinc-300 mt-2">
            <FilterableTable users={drivers} onToggle={requestToggle} />
          </TabsContent>
        </Tabs>
      </div>

      <AlertDialog open={!!pending} onOpenChange={(o) => !o && setPending(null)}>
        <AlertDialogContent className="rounded-none">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display-tight text-2xl">
              {pending?.nextSuspended ? "Suspend this account?" : "Reinstate this account?"}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-sm">
              {pending?.nextSuspended
                ? <>This will immediately block <span className="font-semibold text-zinc-900">{pending?.user.name}</span> ({pending?.user.email}) from signing in or using Chariot. You can reinstate later.</>
                : <>This will restore access for <span className="font-semibold text-zinc-900">{pending?.user.name}</span> ({pending?.user.email}).</>}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="cancel-suspend" className="rounded-none">Cancel</AlertDialogCancel>
            <AlertDialogAction
              data-testid="confirm-suspend"
              onClick={confirmToggle}
              disabled={busy}
              className={`rounded-none ${pending?.nextSuspended ? "bg-red-600 hover:bg-red-700" : "bg-emerald-600 hover:bg-emerald-700"}`}
            >
              {pending?.nextSuspended ? "Yes, suspend" : "Yes, reinstate"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
