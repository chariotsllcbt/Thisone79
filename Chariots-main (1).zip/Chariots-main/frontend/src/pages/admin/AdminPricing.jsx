import { useEffect, useMemo, useState } from "react";
import AdminNav from "@/components/AdminNav";
import api from "@/lib/api";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { RotateCcw, Save, AlertCircle, CheckCircle2 } from "lucide-react";

const DEFAULTS = {
  base_fare: 2.0,
  per_mile: 1.2,
  per_minute: 0.2,
  booking_fee: 0.99,
  competitor_avg_per_mile: 1.5,
  driver_share: 0.85,
  platform_share: 0.15,
};

function Field({ label, k, v, onChange, hint, min, max, step = 0.01 }) {
  return (
    <div>
      <label className="overline text-zinc-500 block mb-1">{label}</label>
      <div className="relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 text-sm">$</span>
        <Input
          data-testid={`pricing-${k}`}
          type="number"
          step={step}
          min={min}
          max={max}
          value={v}
          onChange={(e) => onChange(k, parseFloat(e.target.value || "0"))}
          className="pl-7 rounded-none"
        />
      </div>
      {hint && <div className="text-xs text-zinc-500 mt-1">{hint}</div>}
    </div>
  );
}

export default function AdminPricing() {
  const [p, setP] = useState(null);          // current (saved) state from server
  const [draft, setDraft] = useState(null);   // working copy
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get("/pricing").then(({ data }) => { setP(data); setDraft(data); });
  }, []);

  // mutations
  const set = (k, v) => {
    setDraft((d) => {
      const next = { ...d, [k]: v };
      // Auto-balance: if user edits driver_share, platform_share = 1 - driver_share (clamp 0..1)
      if (k === "driver_share") {
        const clamped = Math.max(0, Math.min(1, v));
        next.driver_share = clamped;
        next.platform_share = +(1 - clamped).toFixed(4);
      } else if (k === "platform_share") {
        const clamped = Math.max(0, Math.min(1, v));
        next.platform_share = clamped;
        next.driver_share = +(1 - clamped).toFixed(4);
      }
      return next;
    });
  };

  const reset = () => setDraft({ ...DEFAULTS });
  const discard = () => setDraft({ ...p });

  const errors = useMemo(() => {
    if (!draft) return [];
    const errs = [];
    ["base_fare", "per_mile", "per_minute", "booking_fee", "competitor_avg_per_mile"].forEach((k) => {
      if (draft[k] < 0) errs.push(`${k.replace(/_/g, " ")} cannot be negative`);
    });
    const sum = +(draft.driver_share + draft.platform_share).toFixed(4);
    if (Math.abs(sum - 1) > 0.001) errs.push(`Driver share + platform share must equal 1.00 (currently ${sum.toFixed(2)})`);
    if (draft.driver_share < 0 || draft.driver_share > 1) errs.push("Driver share must be between 0 and 1");
    return errs;
  }, [draft]);

  const isDirty = useMemo(() => {
    if (!p || !draft) return false;
    return JSON.stringify(p) !== JSON.stringify(draft);
  }, [p, draft]);

  const save = async () => {
    if (errors.length) { toast.error(errors[0]); return; }
    setBusy(true);
    try {
      const { data } = await api.patch("/pricing", draft);
      setP(data); setDraft(data);
      toast.success("Pricing updated");
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Failed to save");
    } finally { setBusy(false); }
  };

  if (!draft) return <div className="min-h-screen bg-white"><AdminNav /><div className="p-6">Loading...</div></div>;

  const exampleFare = draft.base_fare + draft.booking_fee + draft.per_mile * 5 + draft.per_minute * 12;
  const driverEarn = exampleFare * draft.driver_share;
  const competitor = exampleFare / 0.80;
  const savings = competitor - exampleFare;

  return (
    <div className="min-h-screen bg-zinc-50">
      <AdminNav />
      <div className="max-w-4xl mx-auto p-4 sm:p-6">
        <div className="overline text-amber-600">PRICING CONFIG</div>
        <h1 className="font-display-tight text-4xl mb-2">Rate card</h1>
        <p className="text-sm text-zinc-500 mb-6">Changes affect all future ride estimates and bookings. Driver/platform shares auto-balance to sum to 100%.</p>

        {isDirty && (
          <div className="mb-4 border border-amber-300 bg-amber-50 px-4 py-2.5 text-sm flex items-center gap-2" data-testid="unsaved-banner">
            <AlertCircle className="w-4 h-4 text-amber-600" />
            <span className="text-zinc-700"><span className="font-semibold">Unsaved changes.</span> Save or discard to continue.</span>
            <button data-testid="discard-changes" onClick={discard} className="ml-auto text-xs underline text-zinc-600 hover:text-zinc-900">Discard</button>
          </div>
        )}

        <div className="bg-white border border-zinc-300 p-6">
          <div className="overline text-zinc-500 mb-4">FARE FORMULA</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <Field label="Base fare" k="base_fare" v={draft.base_fare} onChange={set} min={0} hint="Flat fee added to every ride" />
            <Field label="Booking fee" k="booking_fee" v={draft.booking_fee} onChange={set} min={0} hint="Service charge" />
            <Field label="Per mile" k="per_mile" v={draft.per_mile} onChange={set} min={0} hint="Distance rate" />
            <Field label="Per minute" k="per_minute" v={draft.per_minute} onChange={set} min={0} hint="Time rate" />
          </div>

          <div className="overline text-zinc-500 mt-8 mb-4">REVENUE SPLIT (AUTO-BALANCES TO 100%)</div>
          <div className="grid grid-cols-2 gap-5">
            <Field label="Driver share" k="driver_share" v={draft.driver_share} onChange={set} min={0} max={1} step={0.01} hint={`= ${Math.round(draft.driver_share * 100)}% to driver`} />
            <Field label="Platform share" k="platform_share" v={draft.platform_share} onChange={set} min={0} max={1} step={0.01} hint={`= ${Math.round(draft.platform_share * 100)}% platform fee`} />
          </div>

          <div className="overline text-zinc-500 mt-8 mb-4">COMPETITOR BENCHMARK</div>
          <Field label="Competitor average per-mile" k="competitor_avg_per_mile" v={draft.competitor_avg_per_mile} onChange={set} min={0} hint="Reference used for '20% cheaper' marketing" />
        </div>

        {errors.length > 0 && (
          <div className="mt-4 border border-red-300 bg-red-50 px-4 py-3 text-sm" data-testid="errors-banner">
            <div className="font-semibold text-red-700 mb-1">Please fix:</div>
            <ul className="list-disc list-inside text-red-700 space-y-0.5">
              {errors.map((e, i) => <li key={i}>{e}</li>)}
            </ul>
          </div>
        )}

        <div className="mt-6 flex flex-wrap gap-3 items-center">
          <Button
            data-testid="save-pricing"
            onClick={save}
            disabled={busy || !isDirty || errors.length > 0}
            className="rounded-none bg-zinc-900 hover:bg-amber-500 hover:text-zinc-900 h-11 px-8 disabled:opacity-40"
          >
            <Save className="w-4 h-4 mr-2" />
            {busy ? "Saving..." : "Save changes"}
          </Button>
          <Button
            data-testid="reset-defaults"
            onClick={reset}
            variant="outline"
            className="rounded-none h-11"
          >
            <RotateCcw className="w-4 h-4 mr-2" /> Reset to defaults
          </Button>
          {!isDirty && p && (
            <span className="text-xs text-emerald-700 inline-flex items-center gap-1 ml-2">
              <CheckCircle2 className="w-3.5 h-3.5" /> All changes saved
            </span>
          )}
        </div>

        <div className="mt-6 bg-amber-50 border border-amber-300 p-5" data-testid="fare-preview">
          <div className="overline text-amber-700 mb-2">LIVE PREVIEW · 5 mi · 12 min trip</div>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="font-display-tight text-4xl">${exampleFare.toFixed(2)}</div>
              <div className="text-xs text-zinc-500 mt-1">Chariot fare</div>
            </div>
            <div>
              <div className="text-sm text-zinc-500 line-through">${competitor.toFixed(2)}</div>
              <div className="text-xs text-emerald-700 font-semibold">Rider saves ${savings.toFixed(2)}</div>
            </div>
            <div>
              <div className="font-display-tight text-2xl text-emerald-700">${driverEarn.toFixed(2)}</div>
              <div className="text-xs text-zinc-500 mt-1">Driver take-home ({Math.round(draft.driver_share * 100)}%)</div>
            </div>
            <div>
              <div className="font-display-tight text-2xl text-amber-700">${(exampleFare - driverEarn).toFixed(2)}</div>
              <div className="text-xs text-zinc-500 mt-1">Platform ({Math.round(draft.platform_share * 100)}%)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
