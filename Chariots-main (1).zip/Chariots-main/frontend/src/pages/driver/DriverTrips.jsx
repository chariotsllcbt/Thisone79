import { useEffect, useState } from "react";
import DriverNav from "@/components/DriverNav";
import api from "@/lib/api";
import { MapPin, Navigation, Star } from "lucide-react";

export default function DriverTrips() {
  const [rides, setRides] = useState([]);

  useEffect(() => { api.get("/rides/my").then(({data}) => setRides(data)); }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <DriverNav />
      <div className="max-w-5xl mx-auto p-4 sm:p-6">
        <div className="overline text-zinc-500">YOUR TRIPS</div>
        <h1 className="font-display-tight text-4xl mb-6">Trip history</h1>
        {rides.length === 0 ? (
          <div className="border border-dashed border-zinc-800 p-12 text-center text-zinc-500">No trips yet.</div>
        ) : (
          <div className="space-y-3">
            {rides.map((r) => (
              <div key={r.id} data-testid={`trip-${r.id}`} className="bg-zinc-950 border border-zinc-800 p-5">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex-1 min-w-[200px]">
                    <div className="overline text-emerald-400">{r.status} · {new Date(r.created_at).toLocaleString()}</div>
                    <div className="font-display-tight text-xl mt-1">{r.customer_name}</div>
                    <div className="mt-2 space-y-1 text-sm text-zinc-300">
                      <div className="flex items-start gap-2"><MapPin className="w-4 h-4 mt-0.5 text-emerald-400 shrink-0" /> {r.pickup_address}</div>
                      <div className="flex items-start gap-2"><Navigation className="w-4 h-4 mt-0.5 text-zinc-400 shrink-0" /> {r.dropoff_address}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-display-tight text-2xl text-emerald-400">${r.driver_earnings.toFixed(2)}</div>
                    <div className="text-xs text-zinc-500">{r.distance_miles} mi</div>
                    {r.rating && <div className="text-xs text-amber-400 mt-1 flex items-center justify-end gap-1"><Star className="w-3 h-3 fill-current" /> {r.rating}</div>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
