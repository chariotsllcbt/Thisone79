import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { ArrowLeft, Car, ShieldCheck, BadgeCheck, FileCheck } from "lucide-react";

const SIDE = "https://images.unsplash.com/photo-1612805144400-88c7821bf36f?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAxODF8MHwxfHNlYXJjaHwyfHxkcml2ZXIlMjBzdGVlcmluZyUyMHdoZWVsfGVufDB8fHx8MTc3OTQ2MzQyNHww&ixlib=rb-4.1.0&q=85";

const US_STATES = ["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"];

export default function DriverAuth() {
  const nav = useNavigate();
  const { login, register } = useAuth();
  const [mode, setMode] = useState("login"); // login | apply
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(1); // for apply mode: 1/2/3
  const [f, setF] = useState({
    email: "", password: "", name: "", phone: "",
    vehicle_make: "", vehicle_model: "", vehicle_plate: "",
    current_uber: false, current_lyft: false, platform_driver_id: "",
    date_of_birth: "", drivers_license_number: "", drivers_license_state: "OR",
    background_check_consent: false,
  });
  const set = (k, v) => setF({ ...f, [k]: v });

  const submitLogin = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const u = await login(f.email, f.password, "driver");
      toast.success(`Welcome back, ${u.name}`);
      nav("/driver");
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Sign-in failed");
    } finally { setBusy(false); }
  };

  const canStep1 = f.current_uber || f.current_lyft;
  const canStep2 = f.name && f.email && f.password && f.phone && f.platform_driver_id;
  const canStep3 = f.date_of_birth && f.drivers_license_number && f.drivers_license_state && f.vehicle_make && f.vehicle_model && f.vehicle_plate && f.background_check_consent;

  const submitApplication = async (e) => {
    e.preventDefault();
    if (!canStep1 || !canStep2 || !canStep3) {
      toast.error("Please complete all fields and consent to the background check.");
      return;
    }
    setBusy(true);
    try {
      const platforms = [];
      if (f.current_uber) platforms.push("uber");
      if (f.current_lyft) platforms.push("lyft");
      await register({
        email: f.email, password: f.password, name: f.name, role: "driver",
        phone: f.phone,
        vehicle_make: f.vehicle_make, vehicle_model: f.vehicle_model, vehicle_plate: f.vehicle_plate,
        current_platforms: platforms,
        platform_driver_id: f.platform_driver_id,
        date_of_birth: f.date_of_birth,
        drivers_license_number: f.drivers_license_number,
        drivers_license_state: f.drivers_license_state,
        background_check_consent: true,
      });
      toast.success("Application submitted! We'll review your background check shortly.");
      nav("/driver");
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Application failed");
    } finally { setBusy(false); }
  };

  const onGoogle = () => {
    localStorage.setItem("sr_google_role", "driver");
    const redirect = `${window.location.origin}/auth/callback`;
    window.location.href = `https://auth.emergentagent.com/?redirect=${encodeURIComponent(redirect)}`;
  };

  return (
    <div className="min-h-screen flex bg-black text-white">
      <div className="flex-1 flex items-start justify-center p-6 sm:p-10 overflow-y-auto">
        <div className="w-full max-w-md">
          <Link to="/" className="inline-flex items-center gap-2 text-xs mb-6 text-zinc-400 hover:text-white" data-testid="back-home">
            <ArrowLeft className="w-3.5 h-3.5" /> BACK TO HOME
          </Link>
          <div className="flex items-center gap-2 mb-2">
            <img src="/chariot-logo.png" alt="Chariot" className="w-9 h-9 object-cover rounded" />
            <span className="font-display-tight font-extrabold text-xl">Chariot</span>
          </div>
          <div className="overline text-emerald-400 mb-2">DRIVER PORTAL</div>
          <h1 className="font-display-tight text-4xl sm:text-5xl mb-2">Keep 85% of every fare.</h1>
          <p className="text-sm text-zinc-400 mb-6">
            {mode === "login" ? "Sign in to continue." : "Three quick steps to apply."}
          </p>

          {/* Mode toggle */}
          <div className="flex gap-1 p-0.5 bg-zinc-900 border border-zinc-800 mb-6">
            <button onClick={() => setMode("login")} data-testid="mode-login" className={`flex-1 py-2 text-xs font-semibold uppercase tracking-wider ${mode === "login" ? "bg-emerald-500 text-black" : "text-zinc-400 hover:text-white"}`}>Sign in</button>
            <button onClick={() => { setMode("apply"); setStep(1); }} data-testid="mode-apply" className={`flex-1 py-2 text-xs font-semibold uppercase tracking-wider ${mode === "apply" ? "bg-emerald-500 text-black" : "text-zinc-400 hover:text-white"}`}>Apply to drive</button>
          </div>

          {mode === "login" ? (
            <form onSubmit={submitLogin} className="space-y-4">
              <div>
                <label className="overline block mb-1">Email</label>
                <Input data-testid="email-input" type="email" required value={f.email} onChange={(e) => set("email", e.target.value)} className="bg-zinc-900 border-zinc-800 text-white" />
              </div>
              <div>
                <label className="overline block mb-1">Password</label>
                <Input data-testid="password-input" type="password" required value={f.password} onChange={(e) => set("password", e.target.value)} className="bg-zinc-900 border-zinc-800 text-white" />
              </div>
              <Button data-testid="submit-auth" type="submit" disabled={busy} className="w-full rounded-none h-12 text-base font-semibold bg-emerald-500 text-black hover:bg-emerald-400">
                {busy ? "Please wait..." : "Sign in"}
              </Button>
              <div className="my-4 flex items-center gap-3 text-xs text-zinc-500">
                <div className="flex-1 h-px bg-zinc-800" /> OR <div className="flex-1 h-px bg-zinc-800" />
              </div>
              <button type="button" data-testid="google-signin" onClick={onGoogle} className="w-full h-12 border border-zinc-800 hover:bg-zinc-900 flex items-center justify-center gap-2 font-medium text-sm">
                Continue with Google
              </button>
            </form>
          ) : (
            <form onSubmit={submitApplication} className="space-y-5">
              {/* Step indicator */}
              <div className="flex items-center gap-2 text-xs">
                {[1, 2, 3].map((n) => (
                  <div key={n} className={`flex-1 h-1 ${step >= n ? "bg-emerald-500" : "bg-zinc-800"}`} />
                ))}
                <span className="text-zinc-500 ml-2">Step {step}/3</span>
              </div>

              {step === 1 && (
                <div className="space-y-4" data-testid="apply-step-1">
                  <div className="flex items-start gap-3 border border-emerald-500/30 bg-emerald-500/5 p-4">
                    <BadgeCheck className="w-5 h-5 text-emerald-400 mt-0.5 shrink-0" />
                    <div className="text-sm">
                      <div className="font-semibold text-white mb-1">Eligibility check</div>
                      <div className="text-zinc-400 text-xs">Chariot only accepts current rideshare drivers from Uber or Lyft. Confirm where you currently drive.</div>
                    </div>
                  </div>
                  <div className="overline">I currently drive for</div>
                  <label className="flex items-center gap-3 border border-zinc-800 hover:border-emerald-500 p-4 cursor-pointer">
                    <Checkbox data-testid="check-uber" checked={f.current_uber} onCheckedChange={(v) => set("current_uber", !!v)} />
                    <div className="text-sm">
                      <div className="font-semibold">Uber</div>
                      <div className="text-xs text-zinc-500">Active driver account in good standing</div>
                    </div>
                  </label>
                  <label className="flex items-center gap-3 border border-zinc-800 hover:border-emerald-500 p-4 cursor-pointer">
                    <Checkbox data-testid="check-lyft" checked={f.current_lyft} onCheckedChange={(v) => set("current_lyft", !!v)} />
                    <div className="text-sm">
                      <div className="font-semibold">Lyft</div>
                      <div className="text-xs text-zinc-500">Active driver account in good standing</div>
                    </div>
                  </label>
                  <Button data-testid="next-1" type="button" disabled={!canStep1} onClick={() => setStep(2)} className="w-full rounded-none h-12 bg-emerald-500 text-black hover:bg-emerald-400 disabled:opacity-40">Continue</Button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4" data-testid="apply-step-2">
                  <div className="overline">Your account</div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="col-span-2">
                      <label className="overline block mb-1">Full name</label>
                      <Input data-testid="name-input" required value={f.name} onChange={(e) => set("name", e.target.value)} className="bg-zinc-900 border-zinc-800 text-white" />
                    </div>
                    <div className="col-span-2">
                      <label className="overline block mb-1">Email</label>
                      <Input data-testid="email-input" type="email" required value={f.email} onChange={(e) => set("email", e.target.value)} className="bg-zinc-900 border-zinc-800 text-white" />
                    </div>
                    <div className="col-span-2">
                      <label className="overline block mb-1">Password</label>
                      <Input data-testid="password-input" type="password" required value={f.password} onChange={(e) => set("password", e.target.value)} className="bg-zinc-900 border-zinc-800 text-white" />
                    </div>
                    <div className="col-span-2">
                      <label className="overline block mb-1">Phone (US)</label>
                      <Input data-testid="phone-input" required value={f.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+15035551234" className="bg-zinc-900 border-zinc-800 text-white" />
                    </div>
                    <div className="col-span-2">
                      <label className="overline block mb-1">{f.current_uber && f.current_lyft ? "Uber or Lyft driver ID" : f.current_uber ? "Uber driver ID" : "Lyft driver ID"}</label>
                      <Input data-testid="platform-id-input" required value={f.platform_driver_id} onChange={(e) => set("platform_driver_id", e.target.value)} placeholder="Last 6 chars of your driver ID" className="bg-zinc-900 border-zinc-800 text-white" />
                      <div className="text-xs text-zinc-500 mt-1">We use this to verify your status on the platform you drive for.</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button data-testid="back-2" type="button" variant="outline" onClick={() => setStep(1)} className="rounded-none h-12 border-zinc-800 text-zinc-300 hover:bg-zinc-900">Back</Button>
                    <Button data-testid="next-2" type="button" disabled={!canStep2} onClick={() => setStep(3)} className="flex-1 rounded-none h-12 bg-emerald-500 text-black hover:bg-emerald-400 disabled:opacity-40">Continue</Button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4" data-testid="apply-step-3">
                  <div className="flex items-start gap-3 border border-amber-500/30 bg-amber-500/5 p-4">
                    <ShieldCheck className="w-5 h-5 text-amber-400 mt-0.5 shrink-0" />
                    <div className="text-sm">
                      <div className="font-semibold text-white mb-1">Background check</div>
                      <div className="text-zinc-400 text-xs">We run a criminal record + driving record check on every applicant. Information is used solely for the background check and never shared.</div>
                    </div>
                  </div>
                  <div className="overline">Identity</div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="col-span-2">
                      <label className="overline block mb-1">Date of birth</label>
                      <Input data-testid="dob-input" type="date" required value={f.date_of_birth} onChange={(e) => set("date_of_birth", e.target.value)} className="bg-zinc-900 border-zinc-800 text-white" />
                    </div>
                    <div>
                      <label className="overline block mb-1">DL number</label>
                      <Input data-testid="dl-num-input" required value={f.drivers_license_number} onChange={(e) => set("drivers_license_number", e.target.value)} className="bg-zinc-900 border-zinc-800 text-white" />
                    </div>
                    <div>
                      <label className="overline block mb-1">State</label>
                      <select data-testid="dl-state-input" value={f.drivers_license_state} onChange={(e) => set("drivers_license_state", e.target.value)} className="w-full h-10 bg-zinc-900 border border-zinc-800 text-white px-3 text-sm">
                        {US_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="overline pt-2">Vehicle</div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="overline block mb-1">Make</label>
                      <Input data-testid="vehicle-make" required value={f.vehicle_make} onChange={(e) => set("vehicle_make", e.target.value)} placeholder="Toyota" className="bg-zinc-900 border-zinc-800 text-white" />
                    </div>
                    <div>
                      <label className="overline block mb-1">Model</label>
                      <Input data-testid="vehicle-model" required value={f.vehicle_model} onChange={(e) => set("vehicle_model", e.target.value)} placeholder="Camry" className="bg-zinc-900 border-zinc-800 text-white" />
                    </div>
                    <div className="col-span-2">
                      <label className="overline block mb-1">License plate</label>
                      <Input data-testid="vehicle-plate" required value={f.vehicle_plate} onChange={(e) => set("vehicle_plate", e.target.value)} placeholder="ABC-1234" className="bg-zinc-900 border-zinc-800 text-white" />
                    </div>
                  </div>

                  <label className="flex items-start gap-3 border border-zinc-800 p-4 cursor-pointer hover:border-emerald-500">
                    <Checkbox data-testid="consent-check" checked={f.background_check_consent} onCheckedChange={(v) => set("background_check_consent", !!v)} />
                    <div className="text-xs text-zinc-300 leading-relaxed">
                      I consent to Chariot running a criminal background check and motor vehicle record check using the information above. I confirm all information is accurate and I authorise Chariot to verify my driver status with Uber and/or Lyft.
                    </div>
                  </label>

                  <div className="flex gap-2">
                    <Button data-testid="back-3" type="button" variant="outline" onClick={() => setStep(2)} className="rounded-none h-12 border-zinc-800 text-zinc-300 hover:bg-zinc-900">Back</Button>
                    <Button data-testid="submit-application" type="submit" disabled={!canStep3 || busy} className="flex-1 rounded-none h-12 bg-emerald-500 text-black hover:bg-emerald-400 disabled:opacity-40">
                      <FileCheck className="w-4 h-4 mr-2" /> {busy ? "Submitting..." : "Submit application"}
                    </Button>
                  </div>
                </div>
              )}
            </form>
          )}
        </div>
      </div>

      <div className="hidden lg:block flex-1 relative overflow-hidden">
        <img src={SIDE} alt="bg" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40" />
      </div>
    </div>
  );
}
