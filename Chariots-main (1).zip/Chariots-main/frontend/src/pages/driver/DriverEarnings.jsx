import { useEffect, useState } from "react";
import DriverNav from "@/components/DriverNav";
import api from "@/lib/api";

export default function DriverEarnings() {
  const [e, setE] = useState({ total_earnings: 0, today_earnings: 0, total_rides: 0, today_rides: 0 });
  const [rides, setRides] = useState([]);

  useEffect(() => {
    api.get("/drivers/earnings").then(({data}) => setE(data));
    api.get("/rides/my").then(({data}) => setRides(data.filter(r => ["completed","paid"].includes(r.status))));
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <DriverNav />
      <div className="max-w-5xl mx-auto p-4 sm:p-6">
        <div className="overline text-zinc-500">PAYOUTS</div>
        <h1 className="font-display-tight text-4xl mb-6">Earnings</h1>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-emerald-500 text-black p-5">
            <div className="overline">TODAY</div>
            <div className="font-display-tight text-3xl mt-1" data-testid="earn-today">${e.today_earnings.toFixed(2)}</div>
            <div className="text-xs mt-1">{e.today_rides} trips</div>
          </div>
          <div className="bg-zinc-950 border border-zinc-800 p-5">
            <div className="overline text-zinc-500">ALL-TIME</div>
            <div className="font-display-tight text-3xl mt-1">${e.total_earnings.toFixed(2)}</div>
            <div className="text-xs text-zinc-500 mt-1">{e.total_rides} trips</div>
          </div>
          <div className="bg-zinc-950 border border-zinc-800 p-5">
            <div className="overline text-zinc-500">SPLIT</div>
            <div className="font-display-tight text-3xl mt-1">85%</div>
            <div className="text-xs text-zinc-500 mt-1">to you, every ride</div>
          </div>
          <div className="bg-zinc-950 border border-zinc-800 p-5">
            <div className="overline text-zinc-500">AVG / TRIP</div>
            <div className="font-display-tight text-3xl mt-1">${e.total_rides ? (e.total_earnings / e.total_rides).toFixed(2) : "0.00"}</div>
          </div>
        </div>

        <div className="bg-zinc-950 border border-zinc-800">
          <div className="overline text-zinc-500 p-4 border-b border-zinc-800">TRIP-BY-TRIP</div>
          {rides.length === 0 ? (
            <div className="p-8 text-center text-zinc-500">No completed trips yet.</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="text-zinc-500 text-xs uppercase tracking-wider">
                <tr><th className="text-left p-3">Date</th><th className="text-left p-3">Customer</th><th className="text-right p-3">Distance</th><th className="text-right p-3">Fare</th><th className="text-right p-3">You earned</th></tr>
              </thead>
              <tbody>
                {rides.map(r => (
                  <tr key={r.id} className="border-t border-zinc-800">
                    <td className="p-3">{new Date(r.created_at).toLocaleDateString()}</td>
                    <td className="p-3">{r.customer_name}</td>
                    <td className="p-3 text-right">{r.distance_miles} mi</td>
                    <td className="p-3 text-right">${r.fare.toFixed(2)}</td>
                    <td className="p-3 text-right text-emerald-400 font-semibold">${r.driver_earnings.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
