import { useEffect, useState } from "react";
import DriverNav from "@/components/DriverNav";
import MapView from "@/components/MapView";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { MapPin, Navigation, DollarSign, Clock, Loader2, ShieldCheck, ShieldAlert, ShieldX, Hourglass } from "lucide-react";

export default function DriverDashboard() {
  const [online, setOnline] = useState(false);
  const [available, setAvailable] = useState([]);
  const [active, setActive] = useState(null);
  const [earnings, setEarnings] = useState({ total_earnings: 0, today_earnings: 0, total_rides: 0, today_rides: 0 });
  const [profile, setProfile] = useState(null);

  const load = async () => {
    try {
      const prof = await api.get("/drivers/me");
      setProfile(prof.data);
      setOnline(prof.data?.online || false);
      const isApproved = prof.data?.application_status === "approved";
      if (isApproved) {
        const [av, mine, ern] = await Promise.all([
          api.get("/rides/available"),
          api.get("/rides/my"),
          api.get("/drivers/earnings"),
        ]);
        setAvailable(av.data);
        const inflight = mine.data.find((r) => ["accepted", "in_progress"].includes(r.status));
        setActive(inflight || null);
        setEarnings(ern.data);
      } else {
        setAvailable([]); setActive(null);
      }
    } catch (e) {
      // ignore
    }
  };

  useEffect(() => { load(); const t = setInterval(load, 6000); return () => clearInterval(t); }, []);

  const status = profile?.application_status || "approved";
  const isApproved = status === "approved";

  const toggle = async (v) => {
    try {
      await api.post("/drivers/online", { online: v });
      setOnline(v);
      toast.success(v ? "You're online" : "You're offline");
    } catch { toast.error("Failed"); }
  };

  const accept = async (id) => {
    try {
      await api.post(`/rides/${id}/accept`);
      toast.success("Ride accepted");
      load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Could not accept"); }
  };

  const start = async (id) => {
    try { await api.post(`/rides/${id}/start`); toast.success("Trip started"); load(); }
    catch { toast.error("Failed"); }
  };

  const complete = async (id) => {
    try { await api.post(`/rides/${id}/complete`); toast.success("Trip completed. Awaiting payment."); load(); }
    catch { toast.error("Failed"); }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <DriverNav />

      {/* Application-status banner */}
      {profile && !isApproved && (
        <div className="border-b border-zinc-800" data-testid={`app-status-banner-${status}`}>
          <div className="max-w-7xl mx-auto p-4 sm:p-6">
            {status === "pending_review" && (
              <div className="flex items-start gap-3 border border-amber-500/40 bg-amber-500/10 p-4">
                <Hourglass className="w-6 h-6 text-amber-400 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <div className="font-display-tight text-xl">Application under review</div>
                  <div className="text-sm text-zinc-300 mt-1">Your background check is in progress. You'll receive an SMS the moment you're approved — usually within 24 hours. You can't go online or accept rides until then.</div>
                  <div className="text-xs text-zinc-500 mt-2">Background check: <span className="text-amber-300 font-semibold">{profile.background_check_status?.toUpperCase()}</span> · Status: <span className="text-amber-300 font-semibold">PENDING REVIEW</span></div>
                </div>
              </div>
            )}
            {status === "rejected" && (
              <div className="flex items-start gap-3 border border-red-500/40 bg-red-500/10 p-4">
                <ShieldX className="w-6 h-6 text-red-400 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <div className="font-display-tight text-xl">Application not approved</div>
                  <div className="text-sm text-zinc-300 mt-1">{profile.rejection_reason || "We were unable to approve your application at this time."}</div>
                  <div className="text-xs text-zinc-500 mt-2">If you believe this is in error, contact support at help@chariot.com.</div>
                </div>
              </div>
            )}
            {status === "incomplete" && (
              <div className="flex items-start gap-3 border border-blue-500/40 bg-blue-500/10 p-4">
                <ShieldAlert className="w-6 h-6 text-blue-400 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <div className="font-display-tight text-xl">Finish your driver application</div>
                  <div className="text-sm text-zinc-300 mt-1">You signed in with Google but haven't completed the driver onboarding yet. Please sign out and use "Apply to drive" so we can verify your Uber/Lyft status and run a background check.</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {profile && isApproved && (
        <div className="border-b border-zinc-800/60" data-testid="app-status-banner-approved">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 text-xs text-zinc-500 flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Approved · Background check clear
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-4">
        <aside className="lg:col-span-4 space-y-4">
          {/* Status card */}
          <div className={`bg-zinc-950 border border-zinc-800 p-6 ${!isApproved ? "opacity-50 pointer-events-none" : ""}`}>
            <div className="flex items-center justify-between">
              <div>
                <div className="overline text-zinc-500">STATUS</div>
                <div className="font-display-tight text-3xl mt-1 flex items-center gap-2">
                  {online ? <><span className="w-3 h-3 bg-emerald-400 pulse-dot rounded-full" /> ONLINE</> : <><span className="w-3 h-3 bg-zinc-600 rounded-full" /> OFFLINE</>}
                </div>
              </div>
              <Switch data-testid="online-toggle" checked={online} onCheckedChange={toggle} disabled={!isApproved} className="data-[state=checked]:bg-emerald-500" />
            </div>
            <p className="text-xs text-zinc-500 mt-3">{online ? "You'll receive ride requests." : "Go online to accept rides."}</p>
          </div>

          {/* Earnings card */}
          <div className="bg-zinc-950 border border-zinc-800 p-6">
            <div className="overline text-emerald-400">TODAY'S EARNINGS</div>
            <div className="font-display-tight text-5xl mt-2" data-testid="today-earnings">${earnings.today_earnings.toFixed(2)}</div>
            <div className="text-xs text-zinc-500 mt-1">{earnings.today_rides} {earnings.today_rides === 1 ? "trip" : "trips"} · 85% take-home</div>
            <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-zinc-800">
              <div>
                <div className="overline text-zinc-500">ALL-TIME</div>
                <div className="font-semibold text-xl">${earnings.total_earnings.toFixed(2)}</div>
              </div>
              <div>
                <div className="overline text-zinc-500">TRIPS</div>
                <div className="font-semibold text-xl">{earnings.total_rides}</div>
              </div>
            </div>
          </div>

          {/* Active ride */}
          {active && (
            <div className="bg-emerald-500 text-black border border-emerald-400 p-6">
              <div className="overline">ACTIVE TRIP — {active.status.toUpperCase()}</div>
              <div className="font-display-tight text-2xl mt-1">{active.customer_name}</div>
              <div className="mt-3 space-y-1.5 text-sm">
                <div className="flex items-start gap-2"><MapPin className="w-4 h-4 mt-0.5 shrink-0" /> {active.pickup_address}</div>
                <div className="flex items-start gap-2"><Navigation className="w-4 h-4 mt-0.5 shrink-0" /> {active.dropoff_address}</div>
              </div>
              <div className="flex gap-3 mt-4 text-xs">
                <div><DollarSign className="w-3 h-3 inline" /> You earn ${active.driver_earnings.toFixed(2)}</div>
                <div><Clock className="w-3 h-3 inline" /> ~{Math.round(active.duration_minutes)} min</div>
              </div>
              <div className="flex gap-2 mt-4">
                {active.status === "accepted" && (
                  <Button data-testid="start-trip" onClick={() => start(active.id)} className="rounded-none bg-black text-white hover:bg-zinc-800 w-full">Start trip</Button>
                )}
                {active.status === "in_progress" && (
                  <Button data-testid="complete-trip" onClick={() => complete(active.id)} className="rounded-none bg-black text-white hover:bg-zinc-800 w-full">Complete trip</Button>
                )}
              </div>
            </div>
          )}
        </aside>

        {/* Available requests / Map */}
        <main className="lg:col-span-8 space-y-4">
          {active ? (
            <div className="h-[60vh] border border-zinc-800">
              <MapView pickup={{ lat: active.pickup_lat, lng: active.pickup_lng }} dropoff={{ lat: active.dropoff_lat, lng: active.dropoff_lng }} className="w-full h-full" center={{ lat: active.pickup_lat, lng: active.pickup_lng }} />
            </div>
          ) : (
            <>
              <div className="flex items-end justify-between">
                <div>
                  <div className="overline text-zinc-500">INCOMING</div>
                  <h2 className="font-display-tight text-3xl">Ride requests</h2>
                </div>
                <div className="text-xs text-zinc-500">{available.length} available</div>
              </div>
              {!online && (
                <div className="border border-amber-500/30 bg-amber-500/10 text-amber-300 p-4 text-sm">
                  You're offline. Toggle online to accept rides.
                </div>
              )}
              {available.length === 0 ? (
                <div className="border border-dashed border-zinc-800 p-12 text-center text-zinc-500">
                  <Loader2 className="w-6 h-6 mx-auto animate-spin mb-2 opacity-60" />
                  Waiting for ride requests...
                </div>
              ) : (
                <div className="space-y-3">
                  {available.map((r) => (
                    <div key={r.id} data-testid={`request-${r.id}`} className="bg-zinc-950 border border-zinc-800 hover:border-emerald-500 transition-colors p-5">
                      <div className="flex items-start justify-between gap-4 flex-wrap">
                        <div className="flex-1 min-w-[200px]">
                          <div className="overline text-emerald-400">{r.distance_miles} mi · {Math.round(r.duration_minutes)} min</div>
                          <div className="font-display-tight text-xl mt-1">{r.customer_name}</div>
                          <div className="mt-2 space-y-1 text-sm text-zinc-300">
                            <div className="flex items-start gap-2"><MapPin className="w-4 h-4 mt-0.5 text-emerald-400 shrink-0" /> {r.pickup_address}</div>
                            <div className="flex items-start gap-2"><Navigation className="w-4 h-4 mt-0.5 text-zinc-400 shrink-0" /> {r.dropoff_address}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="overline text-zinc-500">YOUR EARNINGS</div>
                          <div className="font-display-tight text-3xl text-emerald-400">${r.driver_earnings.toFixed(2)}</div>
                          <div className="text-xs text-zinc-500">of ${r.fare.toFixed(2)} fare</div>
                        </div>
                      </div>
                      <Button data-testid={`accept-${r.id}`} onClick={() => accept(r.id)} disabled={!online} className="rounded-none bg-emerald-500 hover:bg-emerald-400 text-black mt-4 w-full h-11 font-semibold">
                        Accept ride
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
