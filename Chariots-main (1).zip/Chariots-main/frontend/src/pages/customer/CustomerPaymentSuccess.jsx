import { useEffect, useState, useRef } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import CustomerNav from "@/components/CustomerNav";
import api from "@/lib/api";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CustomerPaymentSuccess() {
  const [params] = useSearchParams();
  const nav = useNavigate();
  const sessionId = params.get("session_id");
  const [state, setState] = useState({ loading: true, paid: false, expired: false });
  const attemptsRef = useRef(0);

  useEffect(() => {
    if (!sessionId) { setState({ loading: false, paid: false, expired: false }); return; }
    let cancelled = false;

    const poll = async () => {
      if (cancelled) return;
      if (attemptsRef.current >= 8) {
        setState({ loading: false, paid: false, expired: false });
        return;
      }
      try {
        const { data } = await api.get(`/payments/checkout/status/${sessionId}`);
        if (data.payment_status === "paid") {
          setState({ loading: false, paid: true, expired: false });
          return;
        }
        if (data.status === "expired") {
          setState({ loading: false, paid: false, expired: true });
          return;
        }
      } catch {}
      attemptsRef.current += 1;
      setTimeout(poll, 2000);
    };
    poll();
    return () => { cancelled = true; };
  }, [sessionId]);

  return (
    <div className="min-h-screen bg-zinc-50">
      <CustomerNav />
      <div className="max-w-md mx-auto p-6 pt-16 text-center">
        {state.loading ? (
          <>
            <Loader2 className="w-12 h-12 text-[#0055FF] animate-spin mx-auto mb-4" />
            <h1 className="font-display-tight text-3xl mb-2">Confirming payment...</h1>
            <p className="text-sm text-zinc-500">This usually takes a few seconds.</p>
          </>
        ) : state.paid ? (
          <>
            <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
            <h1 className="font-display-tight text-4xl mb-2">Payment confirmed</h1>
            <p className="text-sm text-zinc-500 mb-8">Thanks for riding with Chariot. Your driver has been paid 85% of the fare.</p>
            <Button data-testid="back-to-rides" onClick={() => nav("/customer/rides")} className="rounded-none bg-zinc-900 hover:bg-[#0055FF]">
              Back to rides
            </Button>
          </>
        ) : (
          <>
            <XCircle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
            <h1 className="font-display-tight text-3xl mb-2">{state.expired ? "Session expired" : "Payment not confirmed"}</h1>
            <p className="text-sm text-zinc-500 mb-8">Please try again from your rides page.</p>
            <Button onClick={() => nav("/customer/rides")} className="rounded-none bg-zinc-900 hover:bg-[#0055FF]">Back to rides</Button>
          </>
        )}
      </div>
    </div>
  );
}
