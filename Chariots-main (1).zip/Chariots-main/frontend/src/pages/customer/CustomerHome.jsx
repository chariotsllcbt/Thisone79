import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import CustomerNav from "@/components/CustomerNav";
import MapView, { SERVICE_AREA, isInServiceArea } from "@/components/MapView";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import api from "@/lib/api";
import { MapPin, Navigation, Sparkles, Loader2, AlertTriangle } from "lucide-react";

// Restrict geocoding to OR/WA via viewbox (lng_min, lat_max, lng_max, lat_min) around Portland metro
const VIEWBOX = "-123.5,46.2,-121.8,44.9";

async function geocode(q) {
  const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=us&viewbox=${VIEWBOX}&bounded=1&q=${encodeURIComponent(q)}`;
  const res = await fetch(url, { headers: { "Accept-Language": "en" } });
  const data = await res.json();
  if (!data.length) throw new Error("Address not found in service area");
  return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon), display: data[0].display_name };
}

export default function CustomerHome() {
  const nav = useNavigate();
  const [pickup, setPickup] = useState(null);
  const [dropoff, setDropoff] = useState(null);
  const [pickupQ, setPickupQ] = useState("");
  const [dropoffQ, setDropoffQ] = useState("");
  const [mode, setMode] = useState("pickup");
  const [estimate, setEstimate] = useState(null);
  const [loading, setLoading] = useState(false);
  const [booking, setBooking] = useState(false);
  const [center, setCenter] = useState(SERVICE_AREA.center);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (p) => {
          if (isInServiceArea(p.coords.latitude, p.coords.longitude)) {
            setCenter({ lat: p.coords.latitude, lng: p.coords.longitude });
          }
        },
        () => {},
        { timeout: 5000 }
      );
    }
  }, []);

  const handleMapClick = (pt) => {
    if (!isInServiceArea(pt.lat, pt.lng)) {
      toast.error("That spot is outside our Portland · Vancouver service area.");
      return;
    }
    if (mode === "pickup") {
      setPickup(pt);
      setPickupQ(`${pt.lat.toFixed(4)}, ${pt.lng.toFixed(4)}`);
    } else {
      setDropoff(pt);
      setDropoffQ(`${pt.lat.toFixed(4)}, ${pt.lng.toFixed(4)}`);
    }
  };

  const searchAddr = async (which) => {
    const q = which === "pickup" ? pickupQ : dropoffQ;
    if (!q.trim()) return;
    setLoading(true);
    try {
      const r = await geocode(q);
      const pt = { lat: r.lat, lng: r.lng };
      if (!isInServiceArea(pt.lat, pt.lng)) {
        toast.error("That address is outside our Portland · Vancouver service area.");
        return;
      }
      if (which === "pickup") {
        setPickup(pt); setPickupQ(r.display); setCenter(pt);
      } else {
        setDropoff(pt); setDropoffQ(r.display); setCenter(pt);
      }
    } catch {
      toast.error("Address not found in service area");
    } finally { setLoading(false); }
  };

  const getEstimate = async () => {
    if (!pickup || !dropoff) {
      toast.error("Set both pickup and drop-off");
      return;
    }
    setLoading(true);
    try {
      const { data } = await api.post("/rides/estimate", {
        pickup_lat: pickup.lat, pickup_lng: pickup.lng,
        dropoff_lat: dropoff.lat, dropoff_lng: dropoff.lng,
      });
      setEstimate(data);
    } catch (e) {
      toast.error("Failed to estimate");
    } finally { setLoading(false); }
  };

  const bookRide = async () => {
    if (!estimate) { toast.error("Get a fare estimate first"); return; }
    setBooking(true);
    try {
      const { data } = await api.post("/rides", {
        pickup_lat: pickup.lat, pickup_lng: pickup.lng,
        pickup_address: pickupQ || `${pickup.lat}, ${pickup.lng}`,
        dropoff_lat: dropoff.lat, dropoff_lng: dropoff.lng,
        dropoff_address: dropoffQ || `${dropoff.lat}, ${dropoff.lng}`,
      });
      toast.success("Ride requested! Looking for drivers...");
      nav(`/customer/rides`);
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Failed to book ride");
    } finally { setBooking(false); }
  };

  return (
    <div className="min-h-screen bg-zinc-50">
      <CustomerNav />
      <div className="max-w-7xl mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left panel */}
        <aside className="lg:col-span-4 bg-white border border-zinc-200 p-5 sm:p-6 space-y-4">
          <div>
            <div className="overline text-zinc-500">PLAN YOUR RIDE</div>
            <h2 className="font-display-tight text-2xl mt-1">Where to today?</h2>
          </div>

          <div className="flex items-start gap-2 border border-zinc-200 bg-zinc-50 p-3 text-xs text-zinc-600" data-testid="service-area-banner">
            <AlertTriangle className="w-4 h-4 mt-0.5 text-amber-500 shrink-0" />
            <div>
              <div className="font-semibold text-zinc-900">Service area: Portland OR · Vancouver WA</div>
              Within 30 mi of downtown Portland — covers Beaverton, Hillsboro, Tigard, Lake Oswego, Gresham, Vancouver WA, Camas and surrounding suburbs.
            </div>
          </div>

          <Tabs value={mode} onValueChange={setMode}>
            <TabsList className="grid grid-cols-2 rounded-none">
              <TabsTrigger value="pickup" data-testid="tab-pickup" className="rounded-none">Pickup</TabsTrigger>
              <TabsTrigger value="dropoff" data-testid="tab-dropoff" className="rounded-none">Drop-off</TabsTrigger>
            </TabsList>
            <TabsContent value="pickup" className="space-y-2">
              <div className="overline text-zinc-500">Pickup address</div>
              <div className="flex gap-2">
                <Input data-testid="pickup-input" value={pickupQ} onChange={(e) => setPickupQ(e.target.value)} placeholder="SW 5th & Morrison, Portland" />
                <Button data-testid="pickup-search" onClick={() => searchAddr("pickup")} variant="outline" className="rounded-none">Find</Button>
              </div>
              {pickup && <div className="text-xs text-zinc-500 flex items-center gap-1"><MapPin className="w-3 h-3 text-[#0055FF]" /> {pickup.lat.toFixed(4)}, {pickup.lng.toFixed(4)}</div>}
            </TabsContent>
            <TabsContent value="dropoff" className="space-y-2">
              <div className="overline text-zinc-500">Drop-off address</div>
              <div className="flex gap-2">
                <Input data-testid="dropoff-input" value={dropoffQ} onChange={(e) => setDropoffQ(e.target.value)} placeholder="PDX Airport · Vancouver WA" />
                <Button data-testid="dropoff-search" onClick={() => searchAddr("dropoff")} variant="outline" className="rounded-none">Find</Button>
              </div>
              {dropoff && <div className="text-xs text-zinc-500 flex items-center gap-1"><Navigation className="w-3 h-3" /> {dropoff.lat.toFixed(4)}, {dropoff.lng.toFixed(4)}</div>}
            </TabsContent>
          </Tabs>

          <Button data-testid="get-estimate-btn" onClick={getEstimate} disabled={!pickup || !dropoff || loading} className="w-full rounded-none bg-zinc-900 hover:bg-[#0055FF] h-11">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Get fare estimate"}
          </Button>

          {estimate && (
            <div className="border border-zinc-900 bg-white p-5 space-y-3">
              <div className="overline text-[#0055FF] flex items-center gap-1"><Sparkles className="w-3 h-3" /> SWIFTRIDE FARE</div>
              <div className="flex items-end justify-between">
                <div className="font-display-tight text-5xl" data-testid="fare-amount">${estimate.fare.toFixed(2)}</div>
                <div className="text-right">
                  <div className="text-xs text-zinc-400 line-through">${estimate.competitor_fare.toFixed(2)}</div>
                  <div className="text-xs text-emerald-600 font-semibold">Save ${estimate.savings.toFixed(2)}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm pt-2 border-t border-zinc-200">
                <div>
                  <div className="overline text-zinc-500">DISTANCE</div>
                  <div className="font-semibold">{estimate.distance_miles} mi</div>
                </div>
                <div>
                  <div className="overline text-zinc-500">ETA</div>
                  <div className="font-semibold">{Math.round(estimate.duration_minutes)} min</div>
                </div>
              </div>
              <div className="text-xs text-zinc-500 pt-2 border-t border-zinc-200">
                Your driver earns <span className="font-semibold text-zinc-900">${estimate.driver_earnings.toFixed(2)}</span> from this ride.
              </div>
              <Button data-testid="book-ride-btn" onClick={bookRide} disabled={booking} className="w-full rounded-none bg-[#0055FF] hover:bg-[#0044CC] h-12 text-base font-semibold">
                {booking ? <Loader2 className="w-4 h-4 animate-spin" /> : "Request ride"}
              </Button>
            </div>
          )}
        </aside>

        {/* Map */}
        <main className="lg:col-span-8 h-[60vh] lg:h-[80vh] border border-zinc-200 bg-white">
          <MapView
            pickup={pickup}
            dropoff={dropoff}
            onMapClick={handleMapClick}
            mode={mode}
            center={center}
            className="w-full h-full"
          />
        </main>
      </div>
    </div>
  );
}
