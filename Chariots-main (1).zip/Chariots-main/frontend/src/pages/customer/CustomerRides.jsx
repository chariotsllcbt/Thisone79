import { useEffect, useState } from "react";
import CustomerNav from "@/components/CustomerNav";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { CreditCard, Star, Loader2, MapPin, Navigation } from "lucide-react";

const StatusBadge = ({ s }) => {
  const map = {
    pending: ["Searching", "bg-amber-100 text-amber-800"],
    accepted: ["Driver assigned", "bg-blue-100 text-blue-800"],
    in_progress: ["On the way", "bg-indigo-100 text-indigo-800"],
    completed: ["Awaiting payment", "bg-orange-100 text-orange-800"],
    paid: ["Paid", "bg-emerald-100 text-emerald-800"],
    cancelled: ["Cancelled", "bg-zinc-100 text-zinc-600"],
  };
  const [label, cls] = map[s] || [s, "bg-zinc-100"];
  return <span className={`inline-block px-2 py-0.5 text-xs font-semibold ${cls}`}>{label}</span>;
};

export default function CustomerRides() {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState(null);
  const [rateOpen, setRateOpen] = useState(null);
  const [rating, setRating] = useState(5);
  const [review, setReview] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/rides/my");
      setRides(data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); const t = setInterval(load, 6000); return () => clearInterval(t); }, []);

  const pay = async (ride) => {
    setPaying(ride.id);
    try {
      const { data } = await api.post("/payments/checkout/session", {
        ride_id: ride.id,
        origin_url: window.location.origin,
      });
      window.location.href = data.url;
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Could not start payment");
      setPaying(null);
    }
  };

  const cancel = async (id) => {
    try {
      await api.post(`/rides/${id}/cancel`);
      toast.success("Ride cancelled");
      load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Cancel failed");
    }
  };

  const submitRating = async () => {
    try {
      await api.post(`/rides/${rateOpen}/rate`, { rating, review });
      toast.success("Thanks for rating!");
      setRateOpen(null); setRating(5); setReview(""); load();
    } catch (e) {
      toast.error("Failed");
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50">
      <CustomerNav />
      <div className="max-w-5xl mx-auto p-4 sm:p-6">
        <div className="flex items-end justify-between mb-6">
          <div>
            <div className="overline text-zinc-500">YOUR TRIPS</div>
            <h1 className="font-display-tight text-3xl sm:text-4xl">Ride history</h1>
          </div>
          <Button onClick={load} variant="outline" className="rounded-none" data-testid="refresh-rides">Refresh</Button>
        </div>

        {loading && rides.length === 0 ? (
          <div className="text-zinc-500">Loading...</div>
        ) : rides.length === 0 ? (
          <div className="border border-dashed border-zinc-300 p-12 text-center text-zinc-500">
            No rides yet. Book your first ride to see it here.
          </div>
        ) : (
          <div className="space-y-3">
            {rides.map((r) => (
              <div key={r.id} data-testid={`ride-${r.id}`} className="bg-white border border-zinc-200 p-5 hover:border-zinc-900 transition-colors">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex-1 min-w-[200px]">
                    <div className="flex items-center gap-2 mb-2">
                      <StatusBadge s={r.status} />
                      {r.payment_status === "paid" && <Badge className="bg-emerald-600">Paid</Badge>}
                    </div>
                    <div className="flex items-start gap-2 text-sm">
                      <MapPin className="w-4 h-4 mt-0.5 text-[#0055FF] shrink-0" />
                      <span className="truncate">{r.pickup_address}</span>
                    </div>
                    <div className="flex items-start gap-2 text-sm mt-1">
                      <Navigation className="w-4 h-4 mt-0.5 text-zinc-900 shrink-0" />
                      <span className="truncate">{r.dropoff_address}</span>
                    </div>
                    <div className="text-xs text-zinc-500 mt-2">
                      {r.distance_miles} mi · {Math.round(r.duration_minutes)} min · {new Date(r.created_at).toLocaleString()}
                    </div>
                    {r.driver_name && <div className="text-xs text-zinc-700 mt-1">Driver: <span className="font-semibold">{r.driver_name}</span></div>}
                  </div>
                  <div className="text-right">
                    <div className="font-display-tight text-3xl">${r.fare.toFixed(2)}</div>
                    {r.rating && <div className="text-xs text-amber-600 mt-1 flex items-center justify-end gap-1"><Star className="w-3 h-3 fill-current" /> {r.rating}/5</div>}
                  </div>
                </div>
                <div className="flex gap-2 mt-4 flex-wrap">
                  {r.status === "completed" && r.payment_status !== "paid" && (
                    <Button data-testid={`pay-${r.id}`} onClick={() => pay(r)} disabled={paying === r.id} className="rounded-none bg-[#0055FF] hover:bg-[#0044CC]">
                      {paying === r.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <><CreditCard className="w-4 h-4 mr-2" /> Pay ${r.fare.toFixed(2)}</>}
                    </Button>
                  )}
                  {(r.status === "paid" || (r.status === "completed" && r.payment_status === "paid")) && !r.rating && (
                    <Button data-testid={`rate-${r.id}`} onClick={() => setRateOpen(r.id)} variant="outline" className="rounded-none">
                      <Star className="w-4 h-4 mr-2" /> Rate driver
                    </Button>
                  )}
                  {(r.status === "pending" || r.status === "accepted") && (
                    <Button data-testid={`cancel-${r.id}`} onClick={() => cancel(r.id)} variant="outline" className="rounded-none">
                      Cancel
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={!!rateOpen} onOpenChange={(o) => !o && setRateOpen(null)}>
        <DialogContent className="rounded-none">
          <DialogHeader><DialogTitle className="font-display-tight text-2xl">Rate your driver</DialogTitle></DialogHeader>
          <div className="flex gap-2 my-4">
            {[1,2,3,4,5].map((n) => (
              <button key={n} data-testid={`star-${n}`} onClick={() => setRating(n)} className="p-1">
                <Star className={`w-8 h-8 ${n <= rating ? "fill-amber-400 text-amber-400" : "text-zinc-300"}`} />
              </button>
            ))}
          </div>
          <Input data-testid="review-input" value={review} onChange={(e) => setReview(e.target.value)} placeholder="Optional review..." />
          <DialogFooter>
            <Button data-testid="submit-rating" onClick={submitRating} className="rounded-none bg-[#0055FF] hover:bg-[#0044CC]">Submit</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
