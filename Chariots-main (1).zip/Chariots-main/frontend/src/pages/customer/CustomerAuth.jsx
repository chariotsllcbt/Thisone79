import AuthShell from "@/components/AuthShell";

const SIDE = "https://static.prod-images.emergentagent.com/jobs/f6827839-cd51-4ed1-976b-103c6c41792f/images/e8169d0549dc2168442cf3597fa658708f73b84c5db94c21e2013f212c9bef5a.png";

export default function CustomerAuth() {
  return <AuthShell role="customer" kicker="RIDER PORTAL" title="Get there for less." sideImg={SIDE} />;
}
