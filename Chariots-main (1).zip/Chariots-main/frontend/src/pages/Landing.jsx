import { Link } from "react-router-dom";
import { ArrowRight, Car, Wallet, Shield, Sparkles, MapPin, Receipt } from "lucide-react";
import { motion } from "framer-motion";

const HERO_IMG = "https://static.prod-images.emergentagent.com/jobs/f6827839-cd51-4ed1-976b-103c6c41792f/images/e8169d0549dc2168442cf3597fa658708f73b84c5db94c21e2013f212c9bef5a.png";

const Portal = ({ to, title, kicker, desc, accent, testid }) => (
  <Link to={to} data-testid={testid} className={`group relative block bg-white border border-zinc-200 hover:border-zinc-900 transition-all p-6 sm:p-8`}>
    <div className="flex items-start justify-between mb-10">
      <span className="overline text-zinc-500">{kicker}</span>
      <ArrowRight className="w-5 h-5 text-zinc-400 group-hover:text-zinc-900 group-hover:translate-x-1 transition-all" />
    </div>
    <h3 className="font-display-tight text-3xl sm:text-4xl text-zinc-900 mb-3">{title}</h3>
    <p className="text-sm text-zinc-600 leading-relaxed">{desc}</p>
    <div className={`mt-8 h-1 w-12 ${accent} group-hover:w-24 transition-all`} />
  </Link>
);

export default function Landing() {
  return (
    <div className="min-h-screen bg-white text-zinc-900">
      {/* NAV */}
      <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-xl bg-white/70 border-b border-zinc-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2" data-testid="brand-logo">
            <img src="/chariot-logo.png" alt="Chariot" className="w-9 h-9 object-cover rounded-md" />
            <span className="font-display-tight text-xl font-extrabold tracking-tight">Chariot</span>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm text-zinc-600">
            <a href="#how" className="hover:text-zinc-900">How it works</a>
            <a href="#why" className="hover:text-zinc-900">Why Chariot</a>
            <a href="#portals" className="hover:text-zinc-900">Portals</a>
            <a href="#pricing" className="hover:text-zinc-900">Pricing</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/customer/auth" data-testid="nav-customer-login" className="text-sm font-medium px-4 py-2 hover:bg-zinc-100 rounded-none">Sign in</Link>
            <Link to="/customer/auth" data-testid="nav-get-started" className="text-sm font-medium px-4 py-2 bg-zinc-900 text-white hover:bg-[#0055FF] transition-colors">Get started</Link>
          </div>
        </div>
      </header>

      {/* HERO — Tetris Grid */}
      <section className="pt-24 pb-8 relative tetris-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-12 sm:pt-20">
          <div className="grid grid-cols-12 gap-4">
            {/* big heading */}
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="col-span-12 lg:col-span-8">
              <div className="inline-flex items-center gap-2 bg-zinc-900 text-white px-3 py-1 mb-6">
                <Sparkles className="w-3.5 h-3.5" />
                <span className="overline text-white">PORTLAND OR · VANCOUVER WA · 20% LESS THAN UBER</span>
              </div>
              <h1 className="font-display-tight text-5xl sm:text-7xl lg:text-8xl leading-[0.95] text-zinc-900">
                Rides that cost <span className="text-[#F59E0B]">less</span>.<br/>
                Drivers that earn <span className="underline decoration-4 decoration-[#F59E0B] underline-offset-8">more</span>.
              </h1>
              <p className="mt-8 text-lg text-zinc-600 max-w-xl leading-relaxed">
                Chariot is the ride-share platform that gives back. Customers save 20% on every trip. Drivers keep 85% of every fare. We only take 15%. <em>Ride together.</em>
              </p>
              <div className="mt-10 flex flex-wrap gap-3">
                <Link to="/customer/auth" data-testid="hero-customer-cta" className="inline-flex items-center gap-2 bg-zinc-900 text-white px-6 py-4 font-medium hover:bg-[#F59E0B] hover:text-zinc-900 transition-colors">
                  Book a ride <ArrowRight className="w-4 h-4" />
                </Link>
                <Link to="/driver/auth" data-testid="hero-driver-cta" className="inline-flex items-center gap-2 bg-white border border-zinc-900 text-zinc-900 px-6 py-4 font-medium hover:bg-zinc-900 hover:text-white transition-colors">
                  Drive with us <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </motion.div>

            {/* hero image */}
            <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8, delay: 0.2 }} className="col-span-12 lg:col-span-4 lg:row-span-2">
              <div className="relative h-72 lg:h-full min-h-[420px] overflow-hidden border border-zinc-200">
                <img src={HERO_IMG} alt="city" className="w-full h-full object-cover" />
                <div className="absolute bottom-0 inset-x-0 bg-white/95 backdrop-blur-sm p-4 border-t border-zinc-200">
                  <div className="overline text-zinc-500 mb-1">LIVE FARE — PEARL DISTRICT → PDX</div>
                  <div className="flex items-end justify-between">
                    <div>
                      <div className="font-display-tight text-3xl">$18.40</div>
                      <div className="text-xs text-zinc-500">Chariot · 7.8 mi trip</div>
                    </div>
                    <div className="text-right">
                      <div className="text-zinc-400 line-through text-sm">$23.00</div>
                      <div className="text-xs text-[#10B981] font-semibold">Save $4.60</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* small stat tiles */}
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="col-span-6 lg:col-span-4 bg-[#F59E0B] text-zinc-950 p-6 sm:p-8">
              <div className="overline text-zinc-950">DRIVER TAKE-HOME</div>
              <div className="font-display-tight text-5xl sm:text-6xl mt-2">85%</div>
              <p className="text-sm mt-2 text-zinc-950 font-medium">Of every fare. Always. No surge skimming.</p>
            </motion.div>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="col-span-6 lg:col-span-4 bg-zinc-900 text-white p-6 sm:p-8">
              <div className="overline text-zinc-400">RIDER SAVINGS</div>
              <div className="font-display-tight text-5xl sm:text-6xl mt-2">20%</div>
              <p className="text-sm mt-2 text-zinc-300">Cheaper than Uber, Lyft, and traditional cabs.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* SERVICE AREA RIBBON */}
      <section className="border-t border-zinc-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <MapPin className="w-5 h-5 text-[#F59E0B]" />
            <span className="overline text-zinc-500">NOW SERVING</span>
            <span className="font-display-tight text-lg sm:text-xl font-bold tracking-tight">Portland OR · Vancouver WA metro</span>
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-zinc-600">
            {["Portland", "Beaverton", "Hillsboro", "Tigard", "Lake Oswego", "Gresham", "Tualatin", "Vancouver WA", "Camas", "Battle Ground", "Ridgefield"].map((c) => (
              <span key={c} className="inline-flex items-center"><span className="w-1 h-1 bg-zinc-400 rounded-full mr-2" />{c}</span>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="py-24 border-t border-zinc-200 bg-zinc-950 text-white relative overflow-hidden">
        <div className="absolute inset-0 tetris-grid-dark opacity-60 pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
          <div className="flex items-end justify-between mb-14 flex-wrap gap-4">
            <div>
              <div className="overline text-[#F59E0B] mb-2">HOW CHARIOT WORKS</div>
              <h2 className="font-display-tight text-4xl sm:text-6xl leading-[0.95]">
                Three taps.<br/>
                <span className="text-[#F59E0B]">Twenty percent</span> off.
              </h2>
            </div>
            <p className="text-sm text-zinc-400 max-w-md">No surge games. No driver tax. The whole ride from request to receipt — and where every dollar goes.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-zinc-800 border border-zinc-800">
            {/* Step 1 */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5 }}
              className="bg-zinc-950 p-8 sm:p-10 relative group"
              data-testid="how-step-1"
            >
              <div className="absolute top-6 right-6 font-display-tight text-7xl text-zinc-800 group-hover:text-[#F59E0B] transition-colors">01</div>
              <MapPin className="w-7 h-7 text-[#F59E0B] mb-6" strokeWidth={1.8} />
              <h3 className="font-display-tight text-2xl mb-3">Set your route</h3>
              <p className="text-sm text-zinc-400 leading-relaxed mb-6">Drop a pin for pickup, another for drop-off. Or just type the address. Our map lives in the browser — no app store detour.</p>
              {/* mini fake input */}
              <div className="space-y-2">
                <motion.div
                  initial={{ width: "30%" }}
                  whileInView={{ width: "85%" }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.4, duration: 0.8 }}
                  className="h-9 border border-zinc-800 flex items-center px-3 text-xs text-zinc-400 bg-zinc-900"
                >
                  <span className="w-2 h-2 bg-[#F59E0B] rounded-full mr-2" /> 123 Main St
                </motion.div>
                <motion.div
                  initial={{ width: "30%" }}
                  whileInView={{ width: "70%" }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.6, duration: 0.8 }}
                  className="h-9 border border-zinc-800 flex items-center px-3 text-xs text-zinc-400 bg-zinc-900"
                >
                  <span className="w-2 h-2 bg-white rounded-sm mr-2" /> JFK Airport
                </motion.div>
              </div>
            </motion.div>

            {/* Step 2 */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: 0.15 }}
              className="bg-zinc-950 p-8 sm:p-10 relative group"
              data-testid="how-step-2"
            >
              <div className="absolute top-6 right-6 font-display-tight text-7xl text-zinc-800 group-hover:text-[#F59E0B] transition-colors">02</div>
              <Sparkles className="w-7 h-7 text-[#F59E0B] mb-6" strokeWidth={1.8} />
              <h3 className="font-display-tight text-2xl mb-3">See the savings</h3>
              <p className="text-sm text-zinc-400 leading-relaxed mb-6">Your fare is computed from a fixed rate card — no surge, no opaque "service fees". We show you the competitor price right next to ours.</p>
              {/* fare comparison */}
              <div className="border border-[#F59E0B]/40 bg-[#F59E0B]/5 p-4">
                <div className="flex items-end justify-between">
                  <div>
                    <div className="overline text-[#F59E0B]">CHARIOT</div>
                    <motion.div
                      initial={{ opacity: 0 }}
                      whileInView={{ opacity: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.6 }}
                      className="font-display-tight text-4xl mt-1"
                    >$18.40</motion.div>
                  </div>
                  <div className="text-right">
                    <div className="overline text-zinc-500">COMPETITORS</div>
                    <div className="text-zinc-500 line-through text-lg mt-1">$23.00</div>
                  </div>
                </div>
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: "20%" }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.9, duration: 0.7 }}
                  className="mt-3 h-1 bg-[#F59E0B]"
                />
                <div className="text-xs text-[#F59E0B] mt-2 font-semibold">You save 20%</div>
              </div>
            </motion.div>

            {/* Step 3 */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-zinc-950 p-8 sm:p-10 relative group"
              data-testid="how-step-3"
            >
              <div className="absolute top-6 right-6 font-display-tight text-7xl text-zinc-800 group-hover:text-[#F59E0B] transition-colors">03</div>
              <Receipt className="w-7 h-7 text-[#F59E0B] mb-6" strokeWidth={1.8} />
              <h3 className="font-display-tight text-2xl mb-3">Ride, pay, smile</h3>
              <p className="text-sm text-zinc-400 leading-relaxed mb-6">Your driver arrives, takes you there, and gets <span className="text-white font-semibold">85% of every dollar</span>. You pay with Stripe in one tap. Rate. Done.</p>
              {/* split bar */}
              <div className="space-y-2">
                <div className="overline text-zinc-500">FARE SPLIT</div>
                <div className="h-10 w-full bg-zinc-900 border border-zinc-800 flex overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: "85%" }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.5, duration: 1 }}
                    className="bg-[#F59E0B] flex items-center justify-center text-xs font-bold text-zinc-950"
                  >85% DRIVER</motion.div>
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: "15%" }}
                    viewport={{ once: true }}
                    transition={{ delay: 1.4, duration: 0.5 }}
                    className="bg-zinc-700 flex items-center justify-center text-[10px] font-bold text-zinc-300"
                  >15%</motion.div>
                </div>
                <div className="flex justify-between text-[11px] text-zinc-500 pt-1">
                  <span>Driver take-home</span>
                  <span>Platform</span>
                </div>
              </div>
            </motion.div>
          </div>

          {/* CTA row */}
          <div className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-zinc-800 pt-8">
            <div className="text-sm text-zinc-400 max-w-lg">
              That's the whole loop. No referral pyramid. No tip extortion. Just a chariot, a driver, and a fair fare.
            </div>
            <Link
              to="/customer/auth"
              data-testid="how-cta"
              className="inline-flex items-center gap-2 bg-[#F59E0B] text-zinc-950 px-6 py-3 font-semibold hover:bg-white transition-colors"
            >
              Try it free <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* PORTALS */}
      <section id="portals" className="py-24 border-t border-zinc-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-end justify-between mb-12 flex-wrap gap-4">
            <div>
              <div className="overline text-zinc-500 mb-2">THREE APPS · ONE PLATFORM</div>
              <h2 className="font-display-tight text-4xl sm:text-5xl">Pick your portal.</h2>
            </div>
            <p className="text-sm text-zinc-600 max-w-md">Each app is built for its own user — riders, drivers, and the team running the show.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-zinc-200 border border-zinc-200">
            <Portal testid="portal-customer" to="/customer/auth" kicker="FOR RIDERS" title="Customer App" desc="Request rides, see live fare estimates, pay with Stripe, rate drivers." accent="bg-[#F59E0B]" />
            <Portal testid="portal-driver" to="/driver/auth" kicker="FOR DRIVERS" title="Driver App" desc="Go online, accept ride requests, track your 85% earnings in real time." accent="bg-emerald-500" />
            <Portal testid="portal-admin" to="/admin/auth" kicker="FOR OPERATORS" title="Admin Control" desc="Configure pricing, monitor rides, manage users, track platform revenue." accent="bg-amber-500" />
          </div>
        </div>
      </section>

      {/* WHY */}
      <section id="why" className="py-24 bg-zinc-50 border-t border-zinc-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <Wallet className="w-8 h-8 mb-6 text-[#F59E0B]" strokeWidth={1.5} />
            <h3 className="font-display-tight text-2xl mb-3">Fair pricing</h3>
            <p className="text-sm text-zinc-600 leading-relaxed">Transparent, formula-based fares. No hidden surge. Admin-controlled rate card means no surprises.</p>
          </div>
          <div>
            <Car className="w-8 h-8 mb-6 text-[#F59E0B]" strokeWidth={1.5} />
            <h3 className="font-display-tight text-2xl mb-3">Driver-first</h3>
            <p className="text-sm text-zinc-600 leading-relaxed">85% of every dollar goes home with the driver. Real-time earnings dashboard. We win when they win.</p>
          </div>
          <div>
            <Shield className="w-8 h-8 mb-6 text-[#F59E0B]" strokeWidth={1.5} />
            <h3 className="font-display-tight text-2xl mb-3">Built right</h3>
            <p className="text-sm text-zinc-600 leading-relaxed">Real Stripe payments. Real maps. Real operations control. Not a demo — a working platform.</p>
          </div>
        </div>
      </section>

      <footer id="pricing" className="py-12 border-t border-zinc-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4 text-sm text-zinc-500">
          <div className="flex items-center gap-2">
            <img src="/chariot-logo.png" alt="Chariot" className="w-7 h-7 object-cover rounded" />
            <span className="font-display-tight font-extrabold text-zinc-900">Chariot</span>
            <span className="text-zinc-400">© 2026 · Ride together</span>
          </div>
          <div className="flex gap-6">
            <Link to="/customer/auth" className="hover:text-zinc-900">Riders</Link>
            <Link to="/driver/auth" className="hover:text-zinc-900">Drivers</Link>
            <Link to="/admin/auth" className="hover:text-zinc-900">Admin</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
