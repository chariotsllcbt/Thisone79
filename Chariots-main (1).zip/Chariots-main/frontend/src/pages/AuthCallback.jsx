import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";

export default function AuthCallback() {
  const nav = useNavigate();
  const { googleLogin } = useAuth();
  const ran = useRef(false);

  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    const hash = window.location.hash;
    const params = new URLSearchParams(hash.replace(/^#/, ""));
    const session_id = params.get("session_id");
    const role = localStorage.getItem("sr_google_role") || "customer";
    if (!session_id) {
      toast.error("Missing session id");
      nav(`/${role}/auth`);
      return;
    }
    googleLogin(session_id, role)
      .then((u) => {
        localStorage.removeItem("sr_google_role");
        toast.success(`Welcome, ${u.name}`);
        nav(`/${u.role}`);
      })
      .catch((e) => {
        toast.error(e?.response?.data?.detail || "Google sign-in failed");
        nav(`/${role}/auth`);
      });
  }, [googleLogin, nav]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="text-center">
        <div className="font-display-tight text-3xl mb-2">Signing you in...</div>
        <div className="text-sm text-zinc-500">Please wait</div>
      </div>
    </div>
  );
}
