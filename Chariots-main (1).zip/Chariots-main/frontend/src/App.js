import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "@/lib/auth";

import Landing from "@/pages/Landing";

import CustomerAuth from "@/pages/customer/CustomerAuth";
import CustomerHome from "@/pages/customer/CustomerHome";
import CustomerRides from "@/pages/customer/CustomerRides";
import CustomerPaymentSuccess from "@/pages/customer/CustomerPaymentSuccess";

import DriverAuth from "@/pages/driver/DriverAuth";
import DriverDashboard from "@/pages/driver/DriverDashboard";
import DriverEarnings from "@/pages/driver/DriverEarnings";
import DriverTrips from "@/pages/driver/DriverTrips";

import AdminAuth from "@/pages/admin/AdminAuth";
import AdminDashboard from "@/pages/admin/AdminDashboard";
import AdminPricing from "@/pages/admin/AdminPricing";
import AdminUsers from "@/pages/admin/AdminUsers";
import AdminRides from "@/pages/admin/AdminRides";
import AdminDriverApplications from "@/pages/admin/AdminDriverApplications";

import AuthCallback from "@/pages/AuthCallback";

const Protected = ({ role, children }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Navigate to={`/${role}/auth`} replace />;
  if (user.role !== role) return <Navigate to={`/${role}/auth`} replace />;
  return children;
};

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <BrowserRouter>
          <Toaster richColors position="top-right" />
          <Routes>
            <Route path="/" element={<Landing />} />

            <Route path="/auth/callback" element={<AuthCallback />} />

            <Route path="/customer/auth" element={<CustomerAuth />} />
            <Route path="/customer" element={<Protected role="customer"><CustomerHome /></Protected>} />
            <Route path="/customer/rides" element={<Protected role="customer"><CustomerRides /></Protected>} />
            <Route path="/customer/payment-success" element={<Protected role="customer"><CustomerPaymentSuccess /></Protected>} />

            <Route path="/driver/auth" element={<DriverAuth />} />
            <Route path="/driver" element={<Protected role="driver"><DriverDashboard /></Protected>} />
            <Route path="/driver/earnings" element={<Protected role="driver"><DriverEarnings /></Protected>} />
            <Route path="/driver/trips" element={<Protected role="driver"><DriverTrips /></Protected>} />

            <Route path="/admin/auth" element={<AdminAuth />} />
            <Route path="/admin" element={<Protected role="admin"><AdminDashboard /></Protected>} />
            <Route path="/admin/pricing" element={<Protected role="admin"><AdminPricing /></Protected>} />
            <Route path="/admin/users" element={<Protected role="admin"><AdminUsers /></Protected>} />
            <Route path="/admin/rides" element={<Protected role="admin"><AdminRides /></Protected>} />
            <Route path="/admin/applications" element={<Protected role="admin"><AdminDriverApplications /></Protected>} />

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </div>
  );
}

export default App;
