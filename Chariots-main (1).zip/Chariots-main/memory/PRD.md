# SwiftRide — Product Requirements Document

## Original Problem Statement
> Build me a ride share platform with a app for customers a app for drivers and a admin app to control it all. Make ride prices 20% less than all competitors like uber Lyft and cab companies and let all drivers receive 85% of their pay and give the company 15%. Make the apps easy to use.

## User Choices
- Three separate apps/portals (Customer, Driver, Admin) under one deployment
- Stripe payments (test mode)
- Leaflet + OpenStreetMap (no key)
- Both JWT email/password and Emergent Google social login
- Admin-configurable pricing (base, per-mile, per-min, booking fee, splits)

## Architecture
- Backend: FastAPI + Motor (Mongo) + JWT + emergentintegrations.payments.stripe
- Frontend: React + Tailwind + Shadcn UI + Leaflet + Recharts + Framer Motion + Sonner
- Fonts: Cabinet Grotesk (display), Inter (body)
- Brand: SwiftRide. Customer = light blue, Driver = dark+emerald, Admin = light+amber

## User Personas
- **Rider**: wants cheap, easy rides with transparent fares
- **Driver**: wants high take-home (85%) with simple online/accept flow
- **Admin**: wants pricing control + real-time KPI monitoring + user moderation

## Core Requirements (Static)
- Price = base + booking_fee + per_mile * distance + per_minute * duration
- Distance: Haversine; duration: distance/(30mph)
- Driver gets `driver_share` (default 0.85), platform gets `platform_share` (0.15)
- "20% less" tagline: competitor_fare = fare/0.80
- Three portals with separate auth states, role-gated routes

## Implemented (v1 — Feb 2026)
- Landing page with hero, fare comparison preview, portal selector, value props
- Customer: auth (email+Google), map-based ride request, live fare estimate, ride history, Stripe checkout, cancel, rate driver (1-5 + review)
- Driver: auth (email+Google with vehicle), online toggle, incoming requests, accept → start → complete lifecycle, earnings dashboard (today/all-time/avg), trip history
- Admin: auth (email only), KPI dashboard with Recharts (revenue, rides/day), pricing config, user management (suspend/reinstate customers and drivers), ride monitoring table
- Backend: 25+ API endpoints, seeded admin (admin@swiftride.com / Admin@12345), bcrypt passwords, 7-day JWT, Stripe checkout + webhook + status polling, payment_transactions collection

## Backlog (P1)
- Real-time ride matching push (currently 6s polling)
- Driver location updates while online (lat/lng to db.driver_profiles)
- Driver approval workflow (require admin approval before driver can accept rides)
- Multi-stop rides + scheduled rides
- Promo codes / referral system
- Push/SMS notifications via Twilio
- Mobile-optimized PWA install prompts

## Backlog (P2)
- Driver-side tipping after trip
- In-app messaging customer↔driver
- Receipts via Resend email
- Surge pricing (admin toggle with multipliers)
- Multi-vehicle types (economy/XL/luxury)
- Driver earnings payout exports (CSV)

## Known Limitations
- Stripe payment-status lookup may return cached DB state if Stripe API throws (test-key behavior)
- Frontend polls every 6-8s; not WebSocket-driven
- No phone verification
