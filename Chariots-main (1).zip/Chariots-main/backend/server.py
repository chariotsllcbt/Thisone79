from fastapi import FastAPI, APIRouter, HTTPException, Depends, Header, Request, UploadFile, File, Form, Query
from fastapi.responses import Response
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import math
import logging
import uuid
import jwt
import bcrypt
import httpx
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Literal
from datetime import datetime, timezone, timedelta

from emergentintegrations.payments.stripe.checkout import (
    StripeCheckout,
    CheckoutSessionRequest,
)
from notifications import fire_and_forget as sms_fire_and_forget, is_configured as sms_is_configured
import storage as object_storage

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

JWT_SECRET = os.environ["JWT_SECRET"]
JWT_ALG = os.environ.get("JWT_ALGORITHM", "HS256")
STRIPE_API_KEY = os.environ["STRIPE_API_KEY"]
SEED_ADMIN_EMAIL = os.environ.get("SEED_ADMIN_EMAIL", "admin@chariot.com")
SEED_ADMIN_PASSWORD = os.environ.get("SEED_ADMIN_PASSWORD", "Admin@12345")

app = FastAPI(title="Chariot API")
api_router = APIRouter(prefix="/api")
security = HTTPBearer(auto_error=False)

# ============ SERVICE AREA ============
# Chariot operates only in the Portland OR + Vancouver WA metro area.
# 30-mile radius from downtown Portland covers PDX/Beaverton/Hillsboro/Tigard/
# Lake Oswego/Gresham/Milwaukie/Tualatin/West Linn/Wilsonville on the OR side,
# and Vancouver/Camas/Battle Ground/Ridgefield/Washougal on the WA side.
SERVICE_CENTER_LAT = 45.5152
SERVICE_CENTER_LNG = -122.6784
SERVICE_RADIUS_MILES = 30.0
SERVICE_AREA_NAME = "Portland OR · Vancouver WA metro"

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


# ============ MODELS ============
Role = Literal["customer", "driver", "admin"]


class User(BaseModel):
    id: str
    email: str
    name: str
    role: Role
    phone: Optional[str] = None
    suspended: bool = False
    created_at: str


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: Literal["customer", "driver"]
    phone: Optional[str] = None
    vehicle_make: Optional[str] = None
    vehicle_model: Optional[str] = None
    vehicle_plate: Optional[str] = None
    # Driver-only application data
    current_platforms: Optional[List[Literal["uber", "lyft"]]] = None
    platform_driver_id: Optional[str] = None
    date_of_birth: Optional[str] = None  # YYYY-MM-DD
    drivers_license_number: Optional[str] = None
    drivers_license_state: Optional[str] = None
    background_check_consent: Optional[bool] = False


class DriverApplicationDecision(BaseModel):
    reason: Optional[str] = ""


class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    role: Literal["customer", "driver", "admin"]


class AuthResponse(BaseModel):
    token: str
    user: User


class GoogleAuthRequest(BaseModel):
    session_id: str
    role: Literal["customer", "driver"]


class PricingConfig(BaseModel):
    base_fare: float = 2.00
    per_mile: float = 1.20
    per_minute: float = 0.20
    booking_fee: float = 0.99
    competitor_avg_per_mile: float = 1.50  # used for "20% less" display
    driver_share: float = 0.85
    platform_share: float = 0.15


class RideEstimateRequest(BaseModel):
    pickup_lat: float
    pickup_lng: float
    dropoff_lat: float
    dropoff_lng: float


class RideEstimateResponse(BaseModel):
    distance_miles: float
    duration_minutes: float
    fare: float
    competitor_fare: float
    savings: float
    driver_earnings: float


class RideCreate(BaseModel):
    pickup_lat: float
    pickup_lng: float
    pickup_address: str
    dropoff_lat: float
    dropoff_lng: float
    dropoff_address: str


class Ride(BaseModel):
    id: str
    customer_id: str
    customer_name: str
    driver_id: Optional[str] = None
    driver_name: Optional[str] = None
    pickup_lat: float
    pickup_lng: float
    pickup_address: str
    dropoff_lat: float
    dropoff_lng: float
    dropoff_address: str
    distance_miles: float
    duration_minutes: float
    fare: float
    driver_earnings: float
    platform_fee: float
    status: Literal["pending", "accepted", "in_progress", "completed", "cancelled", "paid"]
    payment_status: Literal["unpaid", "pending", "paid", "failed"] = "unpaid"
    rating: Optional[int] = None
    review: Optional[str] = None
    created_at: str
    updated_at: str


class RateRequest(BaseModel):
    rating: int
    review: Optional[str] = ""


class PricingUpdate(BaseModel):
    base_fare: Optional[float] = None
    per_mile: Optional[float] = None
    per_minute: Optional[float] = None
    booking_fee: Optional[float] = None
    competitor_avg_per_mile: Optional[float] = None


class CheckoutRequest(BaseModel):
    ride_id: str
    origin_url: str


# ============ HELPERS ============
def hash_pw(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()


def verify_pw(pw: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode(), hashed.encode())
    except Exception:
        return False


def create_jwt(user_id: str, role: str) -> str:
    payload = {
        "sub": user_id,
        "role": role,
        "exp": datetime.now(timezone.utc) + timedelta(days=7),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


async def get_current_user(creds: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    if not creds:
        raise HTTPException(401, "Not authenticated")
    try:
        payload = jwt.decode(creds.credentials, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.PyJWTError:
        raise HTTPException(401, "Invalid token")
    user = await db.users.find_one({"id": payload["sub"]}, {"_id": 0, "password": 0})
    if not user:
        raise HTTPException(401, "User not found")
    if user.get("suspended"):
        raise HTTPException(403, "Account suspended")
    return user


async def require_role(user: dict, *roles: str):
    if user["role"] not in roles:
        raise HTTPException(403, f"Requires role: {roles}")


async def require_approved_driver(user: dict) -> dict:
    """Returns the driver profile if the driver is approved; otherwise raises 403."""
    await require_role(user, "driver")
    profile = await db.driver_profiles.find_one({"id": user["id"]}, {"_id": 0})
    if not profile:
        raise HTTPException(403, "Driver profile not found")
    status = profile.get("application_status", "pending_review")
    if status != "approved":
        if status == "rejected":
            raise HTTPException(403, f"Your driver application was rejected: {profile.get('rejection_reason') or 'Contact support.'}")
        if status == "incomplete":
            raise HTTPException(403, "Please complete your driver application before accepting rides.")
        raise HTTPException(403, "Your driver application is under review. You'll be notified once approved.")
    return profile


def haversine_miles(lat1, lon1, lat2, lon2) -> float:
    R = 3958.8
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def is_in_service_area(lat: float, lng: float) -> bool:
    return haversine_miles(lat, lng, SERVICE_CENTER_LAT, SERVICE_CENTER_LNG) <= SERVICE_RADIUS_MILES


def ensure_in_service_area(pickup_lat, pickup_lng, dropoff_lat, dropoff_lng):
    pickup_ok = is_in_service_area(pickup_lat, pickup_lng)
    dropoff_ok = is_in_service_area(dropoff_lat, dropoff_lng)
    if not pickup_ok and not dropoff_ok:
        raise HTTPException(400, f"Both pickup and drop-off are outside the {SERVICE_AREA_NAME} service area.")
    if not pickup_ok:
        raise HTTPException(400, f"Pickup is outside the {SERVICE_AREA_NAME} service area.")
    if not dropoff_ok:
        raise HTTPException(400, f"Drop-off is outside the {SERVICE_AREA_NAME} service area.")


async def get_pricing() -> PricingConfig:
    doc = await db.pricing.find_one({"id": "global"}, {"_id": 0})
    if not doc:
        cfg = PricingConfig()
        await db.pricing.insert_one({"id": "global", **cfg.model_dump()})
        return cfg
    doc.pop("id", None)
    return PricingConfig(**doc)


async def compute_fare(distance: float, duration: float) -> dict:
    p = await get_pricing()
    fare = round(p.base_fare + p.booking_fee + p.per_mile * distance + p.per_minute * duration, 2)
    competitor_fare = round(fare / 0.80, 2)  # Chariot is 20% cheaper -> competitor = fare/0.8
    return {
        "fare": fare,
        "competitor_fare": competitor_fare,
        "savings": round(competitor_fare - fare, 2),
        "driver_earnings": round(fare * p.driver_share, 2),
        "platform_fee": round(fare * p.platform_share, 2),
    }


# ============ AUTH ENDPOINTS ============
@api_router.post("/auth/register", response_model=AuthResponse)
async def register(req: RegisterRequest):
    existing = await db.users.find_one({"email": req.email.lower(), "role": req.role})
    if existing:
        raise HTTPException(400, "Account with this email and role already exists")

    # Driver applicants must (1) attest to driving for Uber/Lyft and (2) consent to a background check
    if req.role == "driver":
        platforms = req.current_platforms or []
        if not platforms:
            raise HTTPException(400, "Chariot only accepts current Uber or Lyft drivers. Please select at least one.")
        if not req.background_check_consent:
            raise HTTPException(400, "Background check consent is required to drive with Chariot.")
        if not (req.drivers_license_number and req.drivers_license_state):
            raise HTTPException(400, "Driver's license number and state are required.")
        if not req.date_of_birth:
            raise HTTPException(400, "Date of birth is required for the background check.")
        if not req.platform_driver_id:
            raise HTTPException(400, "Your Uber/Lyft driver ID is required to verify your status.")
        if not (req.vehicle_make and req.vehicle_model and req.vehicle_plate):
            raise HTTPException(400, "Vehicle make, model, and license plate are required.")
        if not req.phone:
            raise HTTPException(400, "Phone number is required so we can contact you about your application.")

    user_id = str(uuid.uuid4())
    doc = {
        "id": user_id,
        "email": req.email.lower(),
        "name": req.name,
        "role": req.role,
        "phone": req.phone,
        "password": hash_pw(req.password),
        "suspended": False,
        "created_at": now_iso(),
        "auth_provider": "password",
    }
    await db.users.insert_one(doc)
    if req.role == "driver":
        await db.driver_profiles.insert_one({
            "id": user_id,
            "vehicle_make": req.vehicle_make or "",
            "vehicle_model": req.vehicle_model or "",
            "vehicle_plate": req.vehicle_plate or "",
            "online": False,
            "current_lat": None,
            "current_lng": None,
            # Application + background-check workflow
            "application_status": "pending_review",  # pending_review | approved | rejected
            "rejection_reason": "",
            "current_platforms": req.current_platforms or [],
            "platform_driver_id": req.platform_driver_id or "",
            "date_of_birth": req.date_of_birth or "",
            "drivers_license_number": req.drivers_license_number or "",
            "drivers_license_state": (req.drivers_license_state or "").upper(),
            "background_check_status": "pending",  # pending | clear | flagged
            "background_check_consent_at": now_iso(),
            "applied_at": now_iso(),
            "reviewed_at": None,
            "reviewed_by": None,
        })
    token = create_jwt(user_id, req.role)
    user = User(id=user_id, email=doc["email"], name=doc["name"], role=req.role, phone=req.phone, suspended=False, created_at=doc["created_at"])
    return AuthResponse(token=token, user=user)


@api_router.post("/auth/login", response_model=AuthResponse)
async def login(req: LoginRequest):
    user = await db.users.find_one({"email": req.email.lower(), "role": req.role}, {"_id": 0})
    if not user or not verify_pw(req.password, user.get("password", "")):
        raise HTTPException(401, "Invalid email or password")
    if user.get("suspended"):
        raise HTTPException(403, "Account suspended")
    token = create_jwt(user["id"], user["role"])
    user.pop("password", None)
    user.pop("auth_provider", None)
    return AuthResponse(token=token, user=User(**user))


@api_router.post("/auth/google", response_model=AuthResponse)
async def google_login(req: GoogleAuthRequest):
    # Emergent Auth: exchange session_id for profile
    async with httpx.AsyncClient(timeout=10) as hx:
        r = await hx.get("https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data", headers={"X-Session-ID": req.session_id})
    if r.status_code != 200:
        raise HTTPException(401, "Invalid Google session")
    data = r.json()
    email = data["email"].lower()
    name = data.get("name", email.split("@")[0])
    user = await db.users.find_one({"email": email, "role": req.role}, {"_id": 0})
    if not user:
        user_id = str(uuid.uuid4())
        doc = {
            "id": user_id,
            "email": email,
            "name": name,
            "role": req.role,
            "phone": None,
            "password": "",
            "suspended": False,
            "created_at": now_iso(),
            "auth_provider": "google",
            "picture": data.get("picture"),
        }
        await db.users.insert_one(doc)
        if req.role == "driver":
            await db.driver_profiles.insert_one({
                "id": user_id, "vehicle_make": "", "vehicle_model": "", "vehicle_plate": "",
                "online": False, "current_lat": None, "current_lng": None,
                # Google-signup drivers must still complete the application
                "application_status": "incomplete",
                "rejection_reason": "",
                "current_platforms": [],
                "platform_driver_id": "",
                "date_of_birth": "",
                "drivers_license_number": "",
                "drivers_license_state": "",
                "background_check_status": "pending",
                "background_check_consent_at": None,
                "applied_at": now_iso(),
                "reviewed_at": None,
                "reviewed_by": None,
            })
        user = doc
    if user.get("suspended"):
        raise HTTPException(403, "Account suspended")
    token = create_jwt(user["id"], user["role"])
    user.pop("password", None)
    user.pop("auth_provider", None)
    user.pop("picture", None)
    return AuthResponse(token=token, user=User(**user))


@api_router.get("/auth/me", response_model=User)
async def me(user: dict = Depends(get_current_user)):
    return User(**user)


# ============ PRICING ============
@api_router.get("/pricing", response_model=PricingConfig)
async def get_pricing_endpoint():
    return await get_pricing()


@api_router.patch("/pricing", response_model=PricingConfig)
async def update_pricing(upd: PricingUpdate, user: dict = Depends(get_current_user)):
    await require_role(user, "admin")
    update_data = {k: v for k, v in upd.model_dump().items() if v is not None}
    if update_data:
        await db.pricing.update_one({"id": "global"}, {"$set": update_data}, upsert=True)
    return await get_pricing()


# ============ RIDES ============
@api_router.post("/rides/estimate", response_model=RideEstimateResponse)
async def estimate(req: RideEstimateRequest):
    ensure_in_service_area(req.pickup_lat, req.pickup_lng, req.dropoff_lat, req.dropoff_lng)
    distance = haversine_miles(req.pickup_lat, req.pickup_lng, req.dropoff_lat, req.dropoff_lng)
    duration = max(distance / 0.5, 3)  # ~30mph -> 0.5 miles/min, min 3 mins
    fare_info = await compute_fare(distance, duration)
    return RideEstimateResponse(
        distance_miles=round(distance, 2),
        duration_minutes=round(duration, 1),
        fare=fare_info["fare"],
        competitor_fare=fare_info["competitor_fare"],
        savings=fare_info["savings"],
        driver_earnings=fare_info["driver_earnings"],
    )


@api_router.post("/rides", response_model=Ride)
async def create_ride(req: RideCreate, user: dict = Depends(get_current_user)):
    await require_role(user, "customer")
    ensure_in_service_area(req.pickup_lat, req.pickup_lng, req.dropoff_lat, req.dropoff_lng)
    distance = haversine_miles(req.pickup_lat, req.pickup_lng, req.dropoff_lat, req.dropoff_lng)
    duration = max(distance / 0.5, 3)
    f = await compute_fare(distance, duration)
    ride_id = str(uuid.uuid4())
    ride = {
        "id": ride_id,
        "customer_id": user["id"],
        "customer_name": user["name"],
        "driver_id": None,
        "driver_name": None,
        "pickup_lat": req.pickup_lat,
        "pickup_lng": req.pickup_lng,
        "pickup_address": req.pickup_address,
        "dropoff_lat": req.dropoff_lat,
        "dropoff_lng": req.dropoff_lng,
        "dropoff_address": req.dropoff_address,
        "distance_miles": round(distance, 2),
        "duration_minutes": round(duration, 1),
        "fare": f["fare"],
        "driver_earnings": f["driver_earnings"],
        "platform_fee": f["platform_fee"],
        "status": "pending",
        "payment_status": "unpaid",
        "rating": None,
        "review": None,
        "created_at": now_iso(),
        "updated_at": now_iso(),
    }
    await db.rides.insert_one(ride.copy())

    # Notify online + approved drivers (fire-and-forget; dormant if Twilio not configured)
    online_driver_ids = [d["id"] async for d in db.driver_profiles.find({"online": True, "application_status": "approved"}, {"id": 1, "_id": 0})]
    if online_driver_ids:
        drivers = await db.users.find({"id": {"$in": online_driver_ids}, "role": "driver", "suspended": False}, {"_id": 0, "phone": 1}).to_list(500)
        body = f"📍 New Chariot ride request — pickup at {req.pickup_address}. Fare: ${f['fare']:.2f} · You earn ${f['driver_earnings']:.2f}. Open the driver app to accept."
        for d in drivers:
            sms_fire_and_forget(d.get("phone"), body)

    return Ride(**ride)


@api_router.get("/rides/my", response_model=List[Ride])
async def my_rides(user: dict = Depends(get_current_user)):
    q = {"customer_id": user["id"]} if user["role"] == "customer" else {"driver_id": user["id"]}
    rides = await db.rides.find(q, {"_id": 0}).sort("created_at", -1).to_list(200)
    return [Ride(**r) for r in rides]


@api_router.get("/rides/available", response_model=List[Ride])
async def available_rides(user: dict = Depends(get_current_user)):
    await require_approved_driver(user)
    rides = await db.rides.find({"status": "pending", "driver_id": None}, {"_id": 0}).sort("created_at", -1).to_list(50)
    return [Ride(**r) for r in rides]


@api_router.get("/rides/{ride_id}", response_model=Ride)
async def get_ride(ride_id: str, user: dict = Depends(get_current_user)):
    ride = await db.rides.find_one({"id": ride_id}, {"_id": 0})
    if not ride:
        raise HTTPException(404, "Ride not found")
    if user["role"] != "admin" and user["id"] not in (ride.get("customer_id"), ride.get("driver_id")):
        raise HTTPException(403, "Not your ride")
    return Ride(**ride)


@api_router.post("/rides/{ride_id}/accept", response_model=Ride)
async def accept_ride(ride_id: str, user: dict = Depends(get_current_user)):
    await require_approved_driver(user)
    result = await db.rides.update_one(
        {"id": ride_id, "status": "pending", "driver_id": None},
        {"$set": {"driver_id": user["id"], "driver_name": user["name"], "status": "accepted", "updated_at": now_iso()}},
    )
    if result.modified_count == 0:
        raise HTTPException(400, "Ride no longer available")
    ride = await db.rides.find_one({"id": ride_id}, {"_id": 0})

    # Notify customer that a driver has accepted
    customer = await db.users.find_one({"id": ride["customer_id"]}, {"_id": 0, "phone": 1})
    profile = await db.driver_profiles.find_one({"id": user["id"]}, {"_id": 0, "vehicle_make": 1, "vehicle_model": 1, "vehicle_plate": 1})
    veh = ""
    if profile:
        v = f"{profile.get('vehicle_make','')} {profile.get('vehicle_model','')}".strip()
        plate = profile.get("vehicle_plate") or ""
        if v or plate:
            veh = f" Look for the {v}{(' · ' + plate) if plate else ''}."
    body = f"🚗 Your Chariot driver {user['name']} is on the way to {ride['pickup_address']}.{veh}"
    sms_fire_and_forget((customer or {}).get("phone"), body)

    return Ride(**ride)


@api_router.post("/rides/{ride_id}/start", response_model=Ride)
async def start_ride(ride_id: str, user: dict = Depends(get_current_user)):
    await require_role(user, "driver")
    result = await db.rides.update_one(
        {"id": ride_id, "driver_id": user["id"], "status": "accepted"},
        {"$set": {"status": "in_progress", "updated_at": now_iso()}},
    )
    if result.modified_count == 0:
        raise HTTPException(400, "Cannot start this ride")
    ride = await db.rides.find_one({"id": ride_id}, {"_id": 0})

    # Notify customer that the driver has arrived / trip started
    customer = await db.users.find_one({"id": ride["customer_id"]}, {"_id": 0, "phone": 1})
    body = f"🛬 Your Chariot driver {user['name']} has arrived. Heading to {ride['dropoff_address']}."
    sms_fire_and_forget((customer or {}).get("phone"), body)

    return Ride(**ride)


@api_router.post("/rides/{ride_id}/complete", response_model=Ride)
async def complete_ride(ride_id: str, user: dict = Depends(get_current_user)):
    await require_role(user, "driver")
    result = await db.rides.update_one(
        {"id": ride_id, "driver_id": user["id"], "status": "in_progress"},
        {"$set": {"status": "completed", "updated_at": now_iso()}},
    )
    if result.modified_count == 0:
        raise HTTPException(400, "Cannot complete this ride")
    ride = await db.rides.find_one({"id": ride_id}, {"_id": 0})
    return Ride(**ride)


@api_router.post("/rides/{ride_id}/cancel", response_model=Ride)
async def cancel_ride(ride_id: str, user: dict = Depends(get_current_user)):
    ride = await db.rides.find_one({"id": ride_id}, {"_id": 0})
    if not ride:
        raise HTTPException(404, "Ride not found")
    if user["id"] not in (ride.get("customer_id"), ride.get("driver_id")) and user["role"] != "admin":
        raise HTTPException(403, "Not your ride")
    if ride["status"] in ("completed", "paid"):
        raise HTTPException(400, "Cannot cancel a completed ride")
    await db.rides.update_one({"id": ride_id}, {"$set": {"status": "cancelled", "updated_at": now_iso()}})
    ride = await db.rides.find_one({"id": ride_id}, {"_id": 0})
    return Ride(**ride)


@api_router.post("/rides/{ride_id}/rate", response_model=Ride)
async def rate_ride(ride_id: str, req: RateRequest, user: dict = Depends(get_current_user)):
    await require_role(user, "customer")
    if req.rating < 1 or req.rating > 5:
        raise HTTPException(400, "Rating must be 1-5")
    result = await db.rides.update_one(
        {"id": ride_id, "customer_id": user["id"], "status": {"$in": ["completed", "paid"]}},
        {"$set": {"rating": req.rating, "review": req.review or "", "updated_at": now_iso()}},
    )
    if result.modified_count == 0:
        raise HTTPException(400, "Can only rate completed rides")
    ride = await db.rides.find_one({"id": ride_id}, {"_id": 0})
    return Ride(**ride)


# ============ DRIVER PROFILE ============
@api_router.post("/drivers/online")
async def toggle_online(payload: dict, user: dict = Depends(get_current_user)):
    await require_approved_driver(user)
    online = bool(payload.get("online", False))
    await db.driver_profiles.update_one({"id": user["id"]}, {"$set": {"online": online}}, upsert=True)
    return {"online": online}


# ============ DRIVER DOCUMENTS (license + insurance) ============
ALLOWED_DOC_TYPES = {"license", "insurance"}
ALLOWED_MIME = {"image/jpeg", "image/jpg", "image/png", "image/webp", "application/pdf"}
MAX_DOC_BYTES = 10 * 1024 * 1024  # 10 MB


@api_router.post("/drivers/documents")
async def upload_driver_document(
    doc_type: str = Form(...),
    file: UploadFile = File(...),
    user: dict = Depends(get_current_user),
):
    await require_role(user, "driver")
    if doc_type not in ALLOWED_DOC_TYPES:
        raise HTTPException(400, "doc_type must be 'license' or 'insurance'")
    content_type = (file.content_type or "").lower()
    if content_type not in ALLOWED_MIME:
        raise HTTPException(400, "File must be JPG, PNG, WEBP, or PDF")
    data = await file.read()
    if len(data) > MAX_DOC_BYTES:
        raise HTTPException(400, "File exceeds 10 MB limit")
    if len(data) == 0:
        raise HTTPException(400, "File is empty")
    ext = object_storage.ext_for(content_type, file.filename or "")
    doc_id = str(uuid.uuid4())
    path = f"{object_storage.APP_NAME}/drivers/{user['id']}/{doc_type}/{doc_id}.{ext}"
    try:
        result = object_storage.put_object(path, data, content_type)
    except Exception as e:
        logger.exception("upload failed")
        raise HTTPException(502, f"Storage upload failed: {e}")
    field = "drivers_license_doc" if doc_type == "license" else "insurance_doc"
    await db.driver_profiles.update_one(
        {"id": user["id"]},
        {"$set": {
            field: {
                "storage_path": result["path"],
                "content_type": content_type,
                "size": result.get("size", len(data)),
                "original_filename": file.filename,
                "uploaded_at": now_iso(),
            },
        }},
    )
    return {"ok": True, "doc_type": doc_type, "size": result.get("size", len(data))}


@api_router.get("/drivers/documents/{doc_type}")
async def get_driver_document(doc_type: str, user: dict = Depends(get_current_user), auth: Optional[str] = Query(None)):
    if doc_type not in ALLOWED_DOC_TYPES:
        raise HTTPException(400, "doc_type must be 'license' or 'insurance'")
    # The driver may view their own document; admins may view any driver's document via the admin route below
    profile = await db.driver_profiles.find_one({"id": user["id"]}, {"_id": 0})
    if not profile:
        raise HTTPException(404, "No profile")
    doc = profile.get("drivers_license_doc" if doc_type == "license" else "insurance_doc")
    if not doc:
        raise HTTPException(404, "Document not uploaded")
    try:
        data, ct = object_storage.get_object(doc["storage_path"])
    except Exception as e:
        raise HTTPException(502, f"Storage fetch failed: {e}")
    return Response(content=data, media_type=doc.get("content_type") or ct)


@api_router.get("/admin/drivers/{driver_id}/documents/{doc_type}")
async def admin_get_driver_document(driver_id: str, doc_type: str, user: dict = Depends(get_current_user), auth: Optional[str] = Query(None)):
    await require_role(user, "admin")
    if doc_type not in ALLOWED_DOC_TYPES:
        raise HTTPException(400, "doc_type must be 'license' or 'insurance'")
    profile = await db.driver_profiles.find_one({"id": driver_id}, {"_id": 0})
    if not profile:
        raise HTTPException(404, "Driver not found")
    doc = profile.get("drivers_license_doc" if doc_type == "license" else "insurance_doc")
    if not doc:
        raise HTTPException(404, "Document not uploaded")
    try:
        data, ct = object_storage.get_object(doc["storage_path"])
    except Exception as e:
        raise HTTPException(502, f"Storage fetch failed: {e}")
    return Response(content=data, media_type=doc.get("content_type") or ct)


@api_router.get("/drivers/me")
async def driver_me(user: dict = Depends(get_current_user)):
    await require_role(user, "driver")
    prof = await db.driver_profiles.find_one({"id": user["id"]}, {"_id": 0})
    return prof or {}


@api_router.get("/drivers/earnings")
async def driver_earnings(user: dict = Depends(get_current_user)):
    await require_role(user, "driver")
    rides = await db.rides.find({"driver_id": user["id"], "status": {"$in": ["completed", "paid"]}}, {"_id": 0, "driver_earnings": 1, "created_at": 1}).to_list(1000)
    total = sum(r.get("driver_earnings", 0) for r in rides)
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    today_rides = [r for r in rides if r.get("created_at", "") >= today_start]
    today_total = sum(r.get("driver_earnings", 0) for r in today_rides)
    return {
        "total_earnings": round(total, 2),
        "today_earnings": round(today_total, 2),
        "total_rides": len(rides),
        "today_rides": len(today_rides),
    }


# ============ ADMIN ============
@api_router.get("/admin/stats")
async def admin_stats(user: dict = Depends(get_current_user)):
    await require_role(user, "admin")
    total_rides = await db.rides.count_documents({})
    completed = await db.rides.count_documents({"status": {"$in": ["completed", "paid"]}})
    customers = await db.users.count_documents({"role": "customer"})
    drivers = await db.users.count_documents({"role": "driver"})
    active_drivers = await db.driver_profiles.count_documents({"online": True})

    # Aggregate revenue totals server-side (no full-document fetch)
    totals_agg = await db.rides.aggregate([
        {"$match": {"status": {"$in": ["completed", "paid"]}}},
        {"$group": {"_id": None, "total_revenue": {"$sum": "$fare"}, "platform_revenue": {"$sum": "$platform_fee"}}},
    ]).to_list(1)
    total_revenue = round(totals_agg[0]["total_revenue"], 2) if totals_agg else 0.0
    platform_revenue = round(totals_agg[0]["platform_revenue"], 2) if totals_agg else 0.0

    # Last-7-days breakdown via aggregation grouping on the first 10 chars of created_at
    daily_agg = await db.rides.aggregate([
        {"$match": {"status": {"$in": ["completed", "paid"]}}},
        {"$group": {
            "_id": {"$substr": ["$created_at", 0, 10]},
            "rides": {"$sum": 1},
            "revenue": {"$sum": "$fare"},
            "platform": {"$sum": "$platform_fee"},
        }},
        {"$sort": {"_id": -1}},
        {"$limit": 7},
    ]).to_list(7)
    daily = [{
        "date": d["_id"],
        "rides": d["rides"],
        "revenue": round(d["revenue"], 2),
        "platform": round(d["platform"], 2),
    } for d in sorted(daily_agg, key=lambda x: x["_id"])]
    return {
        "total_rides": total_rides,
        "completed_rides": completed,
        "total_customers": customers,
        "total_drivers": drivers,
        "active_drivers": active_drivers,
        "total_revenue": total_revenue,
        "platform_revenue": platform_revenue,
        "daily": daily,
    }


@api_router.get("/admin/users")
async def admin_users(role: Optional[str] = None, user: dict = Depends(get_current_user)):
    await require_role(user, "admin")
    q = {}
    if role:
        q["role"] = role
    users = await db.users.find(q, {"_id": 0, "password": 0, "auth_provider": 0}).sort("created_at", -1).to_list(500)
    # Enrich drivers with vehicle info + online status + application status
    if role == "driver" or role is None:
        driver_ids = [u["id"] for u in users if u.get("role") == "driver"]
        if driver_ids:
            profiles = await db.driver_profiles.find({"id": {"$in": driver_ids}}, {"_id": 0}).to_list(500)
            pmap = {p["id"]: p for p in profiles}
            for u in users:
                if u.get("role") == "driver":
                    p = pmap.get(u["id"], {})
                    u["vehicle_make"] = p.get("vehicle_make", "")
                    u["vehicle_model"] = p.get("vehicle_model", "")
                    u["vehicle_plate"] = p.get("vehicle_plate", "")
                    u["online"] = p.get("online", False)
                    u["application_status"] = p.get("application_status", "approved")
                    u["background_check_status"] = p.get("background_check_status", "clear")
                    u["current_platforms"] = p.get("current_platforms", [])
                    u["platform_driver_id"] = p.get("platform_driver_id", "")
                    u["drivers_license_state"] = p.get("drivers_license_state", "")
                    u["rejection_reason"] = p.get("rejection_reason", "")
    return users


@api_router.get("/admin/driver-applications")
async def admin_driver_applications(status: Optional[str] = "pending_review", user: dict = Depends(get_current_user)):
    await require_role(user, "admin")
    q = {} if status == "all" else {"application_status": status}
    profiles = await db.driver_profiles.find(q, {"_id": 0}).sort("applied_at", -1).to_list(500)
    if not profiles:
        return []
    ids = [p["id"] for p in profiles]
    users = await db.users.find({"id": {"$in": ids}}, {"_id": 0, "password": 0, "auth_provider": 0}).to_list(500)
    umap = {u["id"]: u for u in users}
    out = []
    for p in profiles:
        u = umap.get(p["id"]) or {}
        if not u:
            continue
        out.append({
            "id": p["id"],
            "name": u.get("name"),
            "email": u.get("email"),
            "phone": u.get("phone"),
            "suspended": u.get("suspended", False),
            "applied_at": p.get("applied_at"),
            "reviewed_at": p.get("reviewed_at"),
            "application_status": p.get("application_status", "pending_review"),
            "background_check_status": p.get("background_check_status", "pending"),
            "current_platforms": p.get("current_platforms", []),
            "platform_driver_id": p.get("platform_driver_id", ""),
            "date_of_birth": p.get("date_of_birth", ""),
            "drivers_license_number": p.get("drivers_license_number", ""),
            "drivers_license_state": p.get("drivers_license_state", ""),
            "vehicle_make": p.get("vehicle_make", ""),
            "vehicle_model": p.get("vehicle_model", ""),
            "vehicle_plate": p.get("vehicle_plate", ""),
            "rejection_reason": p.get("rejection_reason", ""),
            "background_check_consent_at": p.get("background_check_consent_at"),
            "has_license_doc": bool(p.get("drivers_license_doc")),
            "has_insurance_doc": bool(p.get("insurance_doc")),
            "license_doc_uploaded_at": (p.get("drivers_license_doc") or {}).get("uploaded_at"),
            "insurance_doc_uploaded_at": (p.get("insurance_doc") or {}).get("uploaded_at"),
        })
    return out


@api_router.post("/admin/drivers/{driver_id}/approve")
async def admin_approve_driver(driver_id: str, decision: DriverApplicationDecision, user: dict = Depends(get_current_user)):
    await require_role(user, "admin")
    result = await db.driver_profiles.update_one(
        {"id": driver_id},
        {"$set": {
            "application_status": "approved",
            "background_check_status": "clear",
            "rejection_reason": "",
            "reviewed_at": now_iso(),
            "reviewed_by": user["id"],
        }},
    )
    if result.matched_count == 0:
        raise HTTPException(404, "Driver profile not found")
    driver = await db.users.find_one({"id": driver_id}, {"_id": 0, "phone": 1, "name": 1})
    sms_fire_and_forget((driver or {}).get("phone"), f"✅ Chariot: Welcome aboard, {driver.get('name','driver')}! Your background check is clear and your driver application is approved. Open the app to go online.")
    return {"ok": True}


@api_router.post("/admin/drivers/{driver_id}/reject")
async def admin_reject_driver(driver_id: str, decision: DriverApplicationDecision, user: dict = Depends(get_current_user)):
    await require_role(user, "admin")
    reason = (decision.reason or "Did not meet driver requirements.").strip()
    result = await db.driver_profiles.update_one(
        {"id": driver_id},
        {"$set": {
            "application_status": "rejected",
            "background_check_status": "flagged",
            "rejection_reason": reason,
            "online": False,
            "reviewed_at": now_iso(),
            "reviewed_by": user["id"],
        }},
    )
    if result.matched_count == 0:
        raise HTTPException(404, "Driver profile not found")
    driver = await db.users.find_one({"id": driver_id}, {"_id": 0, "phone": 1, "name": 1})
    sms_fire_and_forget((driver or {}).get("phone"), f"Chariot: We were unable to approve your driver application. Reason: {reason}")
    return {"ok": True, "reason": reason}


@api_router.patch("/admin/users/{user_id}/suspend")
async def admin_suspend(user_id: str, payload: dict, user: dict = Depends(get_current_user)):
    await require_role(user, "admin")
    suspended = bool(payload.get("suspended", True))
    await db.users.update_one({"id": user_id}, {"$set": {"suspended": suspended}})
    return {"ok": True, "suspended": suspended}


@api_router.get("/admin/sms-status")
async def admin_sms_status(user: dict = Depends(get_current_user)):
    await require_role(user, "admin")
    return {
        "configured": sms_is_configured(),
        "from_number": os.environ.get("TWILIO_FROM_NUMBER", "") if sms_is_configured() else "",
    }


@api_router.get("/admin/rides")
async def admin_rides(user: dict = Depends(get_current_user)):
    await require_role(user, "admin")
    rides = await db.rides.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)
    return rides


# ============ STRIPE PAYMENTS ============
@api_router.post("/payments/checkout/session")
async def checkout_session(req: CheckoutRequest, http_request: Request, user: dict = Depends(get_current_user)):
    await require_role(user, "customer")
    ride = await db.rides.find_one({"id": req.ride_id, "customer_id": user["id"]}, {"_id": 0})
    if not ride:
        raise HTTPException(404, "Ride not found")
    if ride["status"] not in ("completed",):
        raise HTTPException(400, "Ride is not ready for payment")
    if ride.get("payment_status") == "paid":
        raise HTTPException(400, "Ride already paid")

    amount = float(ride["fare"])  # server-side amount
    success_url = f"{req.origin_url}/customer/payment-success?session_id={{CHECKOUT_SESSION_ID}}"
    cancel_url = f"{req.origin_url}/customer/rides"
    webhook_url = f"{str(http_request.base_url).rstrip('/')}/api/webhook/stripe"

    stripe = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url=webhook_url)
    checkout_req = CheckoutSessionRequest(
        amount=amount,
        currency="usd",
        success_url=success_url,
        cancel_url=cancel_url,
        metadata={"ride_id": req.ride_id, "user_id": user["id"]},
    )
    session = await stripe.create_checkout_session(checkout_req)

    await db.payment_transactions.insert_one({
        "id": str(uuid.uuid4()),
        "session_id": session.session_id,
        "ride_id": req.ride_id,
        "user_id": user["id"],
        "amount": amount,
        "currency": "usd",
        "status": "initiated",
        "payment_status": "pending",
        "metadata": {"ride_id": req.ride_id, "user_id": user["id"]},
        "created_at": now_iso(),
        "updated_at": now_iso(),
    })
    await db.rides.update_one({"id": req.ride_id}, {"$set": {"payment_status": "pending", "updated_at": now_iso()}})
    return {"url": session.url, "session_id": session.session_id}


@api_router.get("/payments/checkout/status/{session_id}")
async def checkout_status(session_id: str, user: dict = Depends(get_current_user)):
    tx = await db.payment_transactions.find_one({"session_id": session_id}, {"_id": 0})
    if not tx:
        raise HTTPException(404, "Transaction not found")
    if tx["user_id"] != user["id"] and user["role"] != "admin":
        raise HTTPException(403, "Not your transaction")

    stripe = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url="")
    try:
        status = await stripe.get_checkout_status(session_id)
    except Exception as e:
        logger.warning(f"checkout status lookup failed for {session_id}: {e}")
        return {
            "status": tx.get("status", "pending"),
            "payment_status": tx.get("payment_status", "pending"),
            "amount_total": int(round(tx.get("amount", 0) * 100)),
            "currency": tx.get("currency", "usd"),
            "ride_id": tx["ride_id"],
        }
    # idempotent update
    if tx["payment_status"] != "paid" and status.payment_status == "paid":
        await db.payment_transactions.update_one(
            {"session_id": session_id},
            {"$set": {"status": status.status, "payment_status": "paid", "updated_at": now_iso()}},
        )
        await db.rides.update_one(
            {"id": tx["ride_id"]},
            {"$set": {"status": "paid", "payment_status": "paid", "updated_at": now_iso()}},
        )
    elif status.status == "expired":
        await db.payment_transactions.update_one(
            {"session_id": session_id},
            {"$set": {"status": "expired", "payment_status": "failed", "updated_at": now_iso()}},
        )
    return {
        "status": status.status,
        "payment_status": status.payment_status,
        "amount_total": status.amount_total,
        "currency": status.currency,
        "ride_id": tx["ride_id"],
    }


@api_router.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    body = await request.body()
    sig = request.headers.get("Stripe-Signature", "")
    stripe = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url="")
    try:
        evt = await stripe.handle_webhook(body, sig)
    except Exception as e:
        logger.error(f"webhook err: {e}")
        raise HTTPException(400, "Invalid webhook")
    if evt.payment_status == "paid":
        tx = await db.payment_transactions.find_one({"session_id": evt.session_id})
        if tx and tx["payment_status"] != "paid":
            await db.payment_transactions.update_one(
                {"session_id": evt.session_id},
                {"$set": {"payment_status": "paid", "status": "complete", "updated_at": now_iso()}},
            )
            await db.rides.update_one(
                {"id": tx["ride_id"]},
                {"$set": {"status": "paid", "payment_status": "paid", "updated_at": now_iso()}},
            )
    return {"ok": True}


# ============ ROOT ============
@api_router.get("/")
async def root():
    return {"message": "Chariot API", "status": "ok"}


@api_router.get("/service-area")
async def service_area():
    return {
        "name": SERVICE_AREA_NAME,
        "center_lat": SERVICE_CENTER_LAT,
        "center_lng": SERVICE_CENTER_LNG,
        "radius_miles": SERVICE_RADIUS_MILES,
        "cities": [
            "Portland", "Beaverton", "Hillsboro", "Tigard", "Lake Oswego",
            "Gresham", "Milwaukie", "Tualatin", "West Linn", "Wilsonville",
            "Vancouver WA", "Camas", "Battle Ground", "Ridgefield", "Washougal",
        ],
    }


app.include_router(api_router)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    # Seed admin
    admin = await db.users.find_one({"role": "admin", "email": SEED_ADMIN_EMAIL.lower()})
    if not admin:
        await db.users.insert_one({
            "id": str(uuid.uuid4()),
            "email": SEED_ADMIN_EMAIL.lower(),
            "name": "Platform Admin",
            "role": "admin",
            "phone": None,
            "password": hash_pw(SEED_ADMIN_PASSWORD),
            "suspended": False,
            "created_at": now_iso(),
            "auth_provider": "password",
        })
        logger.info(f"Seeded admin: {SEED_ADMIN_EMAIL}")
    # Seed pricing
    await get_pricing()
    # Init object storage (driver documents). Logged-only if it fails — uploads will retry on demand.
    try:
        object_storage.init_storage()
        logger.info("Object storage initialised")
    except Exception as e:
        logger.warning(f"Object storage init failed (will retry per request): {e}")
    # Grandfather existing drivers without an application_status as approved
    grand = await db.driver_profiles.update_many(
        {"application_status": {"$exists": False}},
        {"$set": {
            "application_status": "approved",
            "background_check_status": "clear",
            "current_platforms": [],
            "platform_driver_id": "",
            "date_of_birth": "",
            "drivers_license_number": "",
            "drivers_license_state": "",
            "rejection_reason": "",
            "applied_at": now_iso(),
            "reviewed_at": now_iso(),
            "reviewed_by": "system_grandfather",
            "background_check_consent_at": now_iso(),
        }},
    )
    if grand.modified_count:
        logger.info(f"Grandfathered {grand.modified_count} existing driver profile(s) as approved")


@app.on_event("shutdown")
async def shutdown():
    client.close()
