"""SwiftRide backend API tests covering auth, pricing, rides lifecycle,
driver, admin, and Stripe checkout session creation."""
import os
import uuid
import time
import pytest
import requests

BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/") if os.environ.get("REACT_APP_BACKEND_URL") else "https://rideshare-hub-192.preview.emergentagent.com"
API = f"{BASE_URL}/api"

ADMIN_EMAIL = "admin@chariot.com"
ADMIN_PASSWORD = "Admin@12345"

UNIQUE = uuid.uuid4().hex[:8]
CUSTOMER_EMAIL = f"test_customer_{UNIQUE}@example.com"
DRIVER_EMAIL = f"test_driver_{UNIQUE}@example.com"
PW = "Passw0rd!"

# pickup -> dropoff inside Portland OR / Vancouver WA metro service area
PICKUP = {"lat": 45.5152, "lng": -122.6784, "address": "Downtown Portland, OR"}
DROPOFF = {"lat": 45.6387, "lng": -122.6615, "address": "Vancouver, WA"}
# Outside service area (NYC)
OUT_PICKUP = {"lat": 40.7128, "lng": -74.0060, "address": "Lower Manhattan, NYC"}
OUT_DROPOFF = {"lat": 40.7580, "lng": -73.9855, "address": "Times Square, NYC"}


# ---------- helpers ----------
def _auth_header(token):
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module")
def state():
    return {}


# ---------- health ----------
def test_root():
    r = requests.get(f"{API}/")
    assert r.status_code == 200
    assert r.json().get("status") == "ok"


# ---------- pricing public ----------
def test_pricing_public():
    r = requests.get(f"{API}/pricing")
    assert r.status_code == 200
    data = r.json()
    assert data["driver_share"] == 0.85
    assert data["platform_share"] == 0.15


# ---------- auth ----------
def test_admin_login(state):
    r = requests.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD, "role": "admin"})
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["user"]["role"] == "admin"
    state["admin_token"] = data["token"]


def test_register_customer(state):
    r = requests.post(f"{API}/auth/register", json={
        "email": CUSTOMER_EMAIL, "password": PW, "name": "TEST Customer", "role": "customer", "phone": "+15555550100"
    })
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["user"]["role"] == "customer"
    assert data["user"]["email"] == CUSTOMER_EMAIL
    state["customer_token"] = data["token"]
    state["customer_id"] = data["user"]["id"]


def test_register_driver_missing_platforms_rejected():
    """Driver application without current_platforms must be rejected with 400."""
    r = requests.post(f"{API}/auth/register", json={
        "email": f"test_dx1_{UNIQUE}@example.com", "password": PW, "name": "X", "role": "driver",
        "phone": "+15555550101", "vehicle_make": "Toyota", "vehicle_model": "Camry", "vehicle_plate": "X",
        "background_check_consent": True, "platform_driver_id": "U1",
        "date_of_birth": "1990-01-01", "drivers_license_number": "DL1", "drivers_license_state": "OR",
    })
    assert r.status_code == 400, r.text
    assert "uber" in r.json().get("detail", "").lower() or "lyft" in r.json().get("detail", "").lower()


def test_register_driver_no_consent_rejected():
    r = requests.post(f"{API}/auth/register", json={
        "email": f"test_dx2_{UNIQUE}@example.com", "password": PW, "name": "X", "role": "driver",
        "phone": "+15555550101", "vehicle_make": "Toyota", "vehicle_model": "Camry", "vehicle_plate": "X",
        "current_platforms": ["uber"], "platform_driver_id": "U1", "background_check_consent": False,
        "date_of_birth": "1990-01-01", "drivers_license_number": "DL1", "drivers_license_state": "OR",
    })
    assert r.status_code == 400


def test_register_driver_missing_vehicle_rejected():
    r = requests.post(f"{API}/auth/register", json={
        "email": f"test_dx3_{UNIQUE}@example.com", "password": PW, "name": "X", "role": "driver",
        "phone": "+15555550101", "current_platforms": ["uber"], "platform_driver_id": "U1",
        "background_check_consent": True,
        "date_of_birth": "1990-01-01", "drivers_license_number": "DL1", "drivers_license_state": "OR",
    })
    assert r.status_code == 400


def test_register_driver(state):
    """Full valid driver application -> 200 and pending_review profile."""
    r = requests.post(f"{API}/auth/register", json={
        "email": DRIVER_EMAIL, "password": PW, "name": "TEST Driver", "role": "driver",
        "phone": "+15555550101", "vehicle_make": "Toyota", "vehicle_model": "Camry", "vehicle_plate": f"PL-{UNIQUE}",
        "current_platforms": ["uber", "lyft"], "platform_driver_id": f"UBR-{UNIQUE}",
        "date_of_birth": "1990-05-12", "drivers_license_number": f"OR{UNIQUE}",
        "drivers_license_state": "OR", "background_check_consent": True,
    })
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["user"]["role"] == "driver"
    state["driver_token"] = data["token"]
    state["driver_id"] = data["user"]["id"]


def test_pending_driver_blocked_from_online(state):
    r = requests.post(f"{API}/drivers/online", headers=_auth_header(state["driver_token"]), json={"online": True})
    assert r.status_code == 403, r.text
    assert "review" in r.json().get("detail", "").lower()


def test_pending_driver_blocked_from_available(state):
    r = requests.get(f"{API}/rides/available", headers=_auth_header(state["driver_token"]))
    assert r.status_code == 403


def test_admin_login_for_approval(state):
    r = requests.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD, "role": "admin"})
    assert r.status_code == 200
    state["admin_token"] = r.json()["token"]


def test_admin_list_pending_applications(state):
    r = requests.get(f"{API}/admin/driver-applications?status=pending_review",
                     headers=_auth_header(state["admin_token"]))
    assert r.status_code == 200, r.text
    apps = r.json()
    mine = next((a for a in apps if a["id"] == state["driver_id"]), None)
    assert mine is not None, "New driver not listed in pending_review"
    assert mine["application_status"] == "pending_review"
    assert mine["background_check_status"] == "pending"
    assert set(mine["current_platforms"]) == {"uber", "lyft"}
    assert mine["drivers_license_state"] == "OR"
    assert "password" not in mine
    assert "_id" not in mine


def test_admin_list_all_applications(state):
    r = requests.get(f"{API}/admin/driver-applications?status=all",
                     headers=_auth_header(state["admin_token"]))
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_admin_approve_driver(state):
    r = requests.post(f"{API}/admin/drivers/{state['driver_id']}/approve",
                      headers=_auth_header(state["admin_token"]), json={})
    assert r.status_code == 200, r.text
    # verify state changed
    apps = requests.get(f"{API}/admin/driver-applications?status=approved",
                       headers=_auth_header(state["admin_token"])).json()
    mine = next((a for a in apps if a["id"] == state["driver_id"]), None)
    assert mine is not None
    assert mine["application_status"] == "approved"
    assert mine["background_check_status"] == "clear"


def test_approved_driver_can_go_online(state):
    r = requests.post(f"{API}/drivers/online", headers=_auth_header(state["driver_token"]), json={"online": False})
    assert r.status_code == 200
    assert r.json()["online"] is False


def test_approved_driver_can_see_available(state):
    r = requests.get(f"{API}/rides/available", headers=_auth_header(state["driver_token"]))
    assert r.status_code == 200


def test_admin_reject_driver_flow(state):
    """Register a separate driver, then reject, then verify 403 with reason."""
    email = f"test_reject_{UNIQUE}@example.com"
    reg = requests.post(f"{API}/auth/register", json={
        "email": email, "password": PW, "name": "TEST Reject", "role": "driver",
        "phone": "+15555550109", "vehicle_make": "Honda", "vehicle_model": "Civic", "vehicle_plate": f"RJ-{UNIQUE}",
        "current_platforms": ["uber"], "platform_driver_id": "UR9",
        "date_of_birth": "1991-02-02", "drivers_license_number": f"OR{UNIQUE}R",
        "drivers_license_state": "OR", "background_check_consent": True,
    })
    assert reg.status_code == 200, reg.text
    drv = reg.json()
    rej = requests.post(f"{API}/admin/drivers/{drv['user']['id']}/reject",
                       headers=_auth_header(state["admin_token"]),
                       json={"reason": "Failed background check"})
    assert rej.status_code == 200, rej.text
    assert rej.json().get("reason") == "Failed background check"
    # rejected driver blocked
    blk = requests.post(f"{API}/drivers/online", headers=_auth_header(drv["token"]), json={"online": True})
    assert blk.status_code == 403
    assert "Failed background check" in blk.json().get("detail", "")


def test_register_duplicate(state):
    r = requests.post(f"{API}/auth/register", json={
        "email": CUSTOMER_EMAIL, "password": PW, "name": "Dup", "role": "customer"
    })
    assert r.status_code == 400


def test_login_customer(state):
    r = requests.post(f"{API}/auth/login", json={"email": CUSTOMER_EMAIL, "password": PW, "role": "customer"})
    assert r.status_code == 200
    state["customer_token"] = r.json()["token"]


def test_login_bad_pw():
    r = requests.post(f"{API}/auth/login", json={"email": CUSTOMER_EMAIL, "password": "wrong", "role": "customer"})
    assert r.status_code == 401


def test_auth_me(state):
    r = requests.get(f"{API}/auth/me", headers=_auth_header(state["customer_token"]))
    assert r.status_code == 200
    assert r.json()["email"] == CUSTOMER_EMAIL


def test_me_unauth():
    r = requests.get(f"{API}/auth/me")
    assert r.status_code in (401, 403)


# ---------- pricing admin patch ----------
def test_pricing_patch_admin(state):
    r = requests.patch(f"{API}/pricing", json={"base_fare": 2.50}, headers=_auth_header(state["admin_token"]))
    assert r.status_code == 200, r.text
    assert r.json()["base_fare"] == 2.50
    # revert
    r2 = requests.patch(f"{API}/pricing", json={"base_fare": 2.00}, headers=_auth_header(state["admin_token"]))
    assert r2.status_code == 200


def test_pricing_patch_forbidden(state):
    r = requests.patch(f"{API}/pricing", json={"base_fare": 5.0}, headers=_auth_header(state["customer_token"]))
    assert r.status_code == 403


# ---------- service area ----------
def test_service_area_endpoint():
    r = requests.get(f"{API}/service-area")
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["radius_miles"] == 30 or d["radius_miles"] == 30.0
    assert abs(d["center_lat"] - 45.5152) < 0.001
    assert abs(d["center_lng"] - (-122.6784)) < 0.001
    assert isinstance(d["cities"], list)
    assert len(d["cities"]) >= 10
    assert "Portland" in d["cities"]
    assert "Vancouver WA" in d["cities"]


def test_estimate_portland_ok():
    r = requests.post(f"{API}/rides/estimate", json={
        "pickup_lat": 45.5152, "pickup_lng": -122.6784,
        "dropoff_lat": 45.6387, "dropoff_lng": -122.6615
    })
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["fare"] > 0
    assert d["savings"] > 0
    # 20% cheaper -> competitor = fare/0.8
    assert abs(d["competitor_fare"] - round(d["fare"]/0.8, 2)) < 0.05


def test_estimate_nyc_rejected():
    r = requests.post(f"{API}/rides/estimate", json={
        "pickup_lat": 40.7128, "pickup_lng": -74.0060,
        "dropoff_lat": 40.7580, "dropoff_lng": -73.9855
    })
    assert r.status_code == 400
    msg = r.json().get("detail", "").lower()
    assert "outside" in msg
    assert "portland" in msg


def test_estimate_only_pickup_outside():
    # NYC pickup, Portland dropoff
    r = requests.post(f"{API}/rides/estimate", json={
        "pickup_lat": 40.7128, "pickup_lng": -74.0060,
        "dropoff_lat": 45.5152, "dropoff_lng": -122.6784
    })
    assert r.status_code == 400
    assert "pickup" in r.json().get("detail", "").lower()


def test_estimate_only_dropoff_outside():
    # Portland pickup, NYC dropoff
    r = requests.post(f"{API}/rides/estimate", json={
        "pickup_lat": 45.5152, "pickup_lng": -122.6784,
        "dropoff_lat": 40.7128, "dropoff_lng": -74.0060
    })
    assert r.status_code == 400
    assert "drop" in r.json().get("detail", "").lower()


def test_create_ride_rejected_out_of_area(state):
    # using NYC coords; should 400 and not create a DB doc
    before = requests.get(f"{API}/rides/my", headers=_auth_header(state["customer_token"])).json()
    r = requests.post(f"{API}/rides", headers=_auth_header(state["customer_token"]), json={
        "pickup_lat": OUT_PICKUP["lat"], "pickup_lng": OUT_PICKUP["lng"], "pickup_address": OUT_PICKUP["address"],
        "dropoff_lat": OUT_DROPOFF["lat"], "dropoff_lng": OUT_DROPOFF["lng"], "dropoff_address": OUT_DROPOFF["address"],
    })
    assert r.status_code == 400, r.text
    after = requests.get(f"{API}/rides/my", headers=_auth_header(state["customer_token"])).json()
    assert len(after) == len(before)


# ---------- ride estimate ----------
def test_ride_estimate():
    r = requests.post(f"{API}/rides/estimate", json={
        "pickup_lat": PICKUP["lat"], "pickup_lng": PICKUP["lng"],
        "dropoff_lat": DROPOFF["lat"], "dropoff_lng": DROPOFF["lng"]
    })
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["distance_miles"] > 0
    assert d["fare"] > 0
    # competitor should be ~25% more (fare/0.8)
    assert d["competitor_fare"] > d["fare"]
    # driver earnings ~= 85% of fare
    assert abs(d["driver_earnings"] - round(d["fare"] * 0.85, 2)) < 0.05


# ---------- ride lifecycle ----------
def test_create_ride_customer(state):
    r = requests.post(f"{API}/rides", headers=_auth_header(state["customer_token"]), json={
        "pickup_lat": PICKUP["lat"], "pickup_lng": PICKUP["lng"], "pickup_address": PICKUP["address"],
        "dropoff_lat": DROPOFF["lat"], "dropoff_lng": DROPOFF["lng"], "dropoff_address": DROPOFF["address"],
    })
    assert r.status_code == 200, r.text
    ride = r.json()
    assert ride["status"] == "pending"
    assert ride["fare"] > 0
    # 85/15 split server-side
    assert abs(ride["driver_earnings"] - round(ride["fare"] * 0.85, 2)) < 0.05
    assert abs(ride["platform_fee"] - round(ride["fare"] * 0.15, 2)) < 0.05
    state["ride_id"] = ride["id"]


def test_create_ride_forbidden_for_driver(state):
    r = requests.post(f"{API}/rides", headers=_auth_header(state["driver_token"]), json={
        "pickup_lat": PICKUP["lat"], "pickup_lng": PICKUP["lng"], "pickup_address": "x",
        "dropoff_lat": DROPOFF["lat"], "dropoff_lng": DROPOFF["lng"], "dropoff_address": "y",
    })
    assert r.status_code == 403


def test_rides_my_customer(state):
    r = requests.get(f"{API}/rides/my", headers=_auth_header(state["customer_token"]))
    assert r.status_code == 200
    rides = r.json()
    assert any(x["id"] == state["ride_id"] for x in rides)


def test_available_rides_driver(state):
    r = requests.get(f"{API}/rides/available", headers=_auth_header(state["driver_token"]))
    assert r.status_code == 200
    rides = r.json()
    assert any(x["id"] == state["ride_id"] for x in rides)


def test_available_rides_forbidden_for_customer(state):
    r = requests.get(f"{API}/rides/available", headers=_auth_header(state["customer_token"]))
    assert r.status_code == 403


def test_driver_online_toggle(state):
    r = requests.post(f"{API}/drivers/online", headers=_auth_header(state["driver_token"]), json={"online": True})
    assert r.status_code == 200
    assert r.json()["online"] is True


def test_accept_ride(state):
    r = requests.post(f"{API}/rides/{state['ride_id']}/accept", headers=_auth_header(state["driver_token"]))
    assert r.status_code == 200, r.text
    ride = r.json()
    assert ride["status"] == "accepted"
    assert ride["driver_id"] == state["driver_id"]


def test_accept_ride_again_fails(state):
    r = requests.post(f"{API}/rides/{state['ride_id']}/accept", headers=_auth_header(state["driver_token"]))
    assert r.status_code == 400


def test_start_ride(state):
    r = requests.post(f"{API}/rides/{state['ride_id']}/start", headers=_auth_header(state["driver_token"]))
    assert r.status_code == 200
    assert r.json()["status"] == "in_progress"


def test_complete_ride(state):
    r = requests.post(f"{API}/rides/{state['ride_id']}/complete", headers=_auth_header(state["driver_token"]))
    assert r.status_code == 200
    ride = r.json()
    assert ride["status"] == "completed"
    # 85/15 stays correct
    assert abs(ride["driver_earnings"] - round(ride["fare"] * 0.85, 2)) < 0.05


def test_driver_earnings(state):
    r = requests.get(f"{API}/drivers/earnings", headers=_auth_header(state["driver_token"]))
    assert r.status_code == 200
    d = r.json()
    assert d["total_rides"] >= 1
    assert d["total_earnings"] > 0


def test_rate_ride(state):
    r = requests.post(f"{API}/rides/{state['ride_id']}/rate", headers=_auth_header(state["customer_token"]),
                      json={"rating": 5, "review": "Great"})
    assert r.status_code == 200, r.text
    assert r.json()["rating"] == 5


def test_rate_invalid(state):
    r = requests.post(f"{API}/rides/{state['ride_id']}/rate", headers=_auth_header(state["customer_token"]),
                      json={"rating": 9})
    assert r.status_code == 400


# ---------- second ride for cancel ----------
def test_cancel_ride(state):
    r = requests.post(f"{API}/rides", headers=_auth_header(state["customer_token"]), json={
        "pickup_lat": PICKUP["lat"], "pickup_lng": PICKUP["lng"], "pickup_address": PICKUP["address"],
        "dropoff_lat": DROPOFF["lat"], "dropoff_lng": DROPOFF["lng"], "dropoff_address": DROPOFF["address"],
    })
    rid = r.json()["id"]
    c = requests.post(f"{API}/rides/{rid}/cancel", headers=_auth_header(state["customer_token"]))
    assert c.status_code == 200
    assert c.json()["status"] == "cancelled"


# ---------- admin ----------
def test_admin_stats(state):
    r = requests.get(f"{API}/admin/stats", headers=_auth_header(state["admin_token"]))
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["total_rides"] >= 1
    assert "platform_revenue" in d


def test_admin_users(state):
    r = requests.get(f"{API}/admin/users", headers=_auth_header(state["admin_token"]))
    assert r.status_code == 200
    assert isinstance(r.json(), list)


# ---- Admin Users enriched driver listing (vehicle_make/model/plate + online) ----
def test_admin_users_driver_enriched(state):
    r = requests.get(f"{API}/admin/users?role=driver", headers=_auth_header(state["admin_token"]))
    assert r.status_code == 200, r.text
    drivers = r.json()
    assert isinstance(drivers, list) and len(drivers) > 0
    # find our test driver
    mine = next((d for d in drivers if d.get("email") == DRIVER_EMAIL), None)
    assert mine is not None, f"Test driver {DRIVER_EMAIL} not found in /admin/users?role=driver"
    for f in ("vehicle_make", "vehicle_model", "vehicle_plate", "online"):
        assert f in mine, f"Driver missing enriched field: {f}"
    assert mine["vehicle_make"] == "Toyota"
    assert mine["vehicle_model"] == "Camry"
    assert mine["vehicle_plate"].startswith("PL-")
    assert isinstance(mine["online"], bool)
    # PII never leaked
    assert "password" not in mine
    assert "_id" not in mine


def test_admin_users_customer_no_vehicle(state):
    r = requests.get(f"{API}/admin/users?role=customer", headers=_auth_header(state["admin_token"]))
    assert r.status_code == 200
    customers = r.json()
    assert isinstance(customers, list)
    # customers should not have vehicle fields injected
    for c in customers:
        assert c.get("role") == "customer"
        assert "vehicle_make" not in c
        assert "online" not in c


def test_admin_rides(state):
    r = requests.get(f"{API}/admin/rides", headers=_auth_header(state["admin_token"]))
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_admin_suspend_reinstate(state):
    r = requests.patch(f"{API}/admin/users/{state['customer_id']}/suspend",
                       headers=_auth_header(state["admin_token"]), json={"suspended": True})
    assert r.status_code == 200
    # suspended user blocked from auth/me
    me = requests.get(f"{API}/auth/me", headers=_auth_header(state["customer_token"]))
    assert me.status_code == 403
    # reinstate
    r2 = requests.patch(f"{API}/admin/users/{state['customer_id']}/suspend",
                        headers=_auth_header(state["admin_token"]), json={"suspended": False})
    assert r2.status_code == 200
    me2 = requests.get(f"{API}/auth/me", headers=_auth_header(state["customer_token"]))
    assert me2.status_code == 200


def test_admin_role_enforcement(state):
    r = requests.get(f"{API}/admin/stats", headers=_auth_header(state["customer_token"]))
    assert r.status_code == 403


# ---------- payments ----------
def test_payment_session_creation(state):
    # ride must be completed; we used ride_id earlier and it's completed
    r = requests.post(f"{API}/payments/checkout/session",
                      headers=_auth_header(state["customer_token"]),
                      json={"ride_id": state["ride_id"], "origin_url": BASE_URL})
    assert r.status_code == 200, r.text
    d = r.json()
    assert "url" in d and d["url"].startswith("http")
    assert "session_id" in d
    state["session_id"] = d["session_id"]


def test_payment_status(state):
    if "session_id" not in state:
        pytest.skip("no session")
    r = requests.get(f"{API}/payments/checkout/status/{state['session_id']}",
                     headers=_auth_header(state["customer_token"]))
    assert r.status_code == 200, r.text
    d = r.json()
    # initial state - unpaid/open
    assert "status" in d
    assert "payment_status" in d


def test_payment_session_unpaid_ride_blocked(state):
    # create a fresh pending ride and try to pay -> should fail
    r = requests.post(f"{API}/rides", headers=_auth_header(state["customer_token"]), json={
        "pickup_lat": PICKUP["lat"], "pickup_lng": PICKUP["lng"], "pickup_address": PICKUP["address"],
        "dropoff_lat": DROPOFF["lat"], "dropoff_lng": DROPOFF["lng"], "dropoff_address": DROPOFF["address"],
    })
    rid = r.json()["id"]
    p = requests.post(f"{API}/payments/checkout/session",
                      headers=_auth_header(state["customer_token"]),
                      json={"ride_id": rid, "origin_url": BASE_URL})
    assert p.status_code == 400
