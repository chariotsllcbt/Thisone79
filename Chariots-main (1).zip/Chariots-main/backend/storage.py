"""
Emergent object storage helper for Chariot driver documents.

Stores driver's license and insurance card photos. Files are accessed via the
backend (auth-checked) — no direct storage URLs are exposed to the frontend.
"""
from __future__ import annotations

import logging
import os
import requests
from typing import Tuple

logger = logging.getLogger(__name__)

STORAGE_URL = "https://integrations.emergentagent.com/objstore/api/v1/storage"
APP_NAME = "chariot"

_storage_key: str | None = None


def _get_emergent_key() -> str:
    k = os.environ.get("EMERGENT_LLM_KEY", "").strip()
    if not k:
        raise RuntimeError("EMERGENT_LLM_KEY is not configured")
    return k


def init_storage(force: bool = False) -> str:
    """Initialize a session-scoped storage key. Idempotent unless force=True."""
    global _storage_key
    if _storage_key and not force:
        return _storage_key
    resp = requests.post(f"{STORAGE_URL}/init", json={"emergent_key": _get_emergent_key()}, timeout=30)
    resp.raise_for_status()
    _storage_key = resp.json()["storage_key"]
    return _storage_key


def put_object(path: str, data: bytes, content_type: str) -> dict:
    """Upload bytes to a path. Returns {"path": "...", "size": ..., "etag": "..."}."""
    key = init_storage()
    resp = requests.put(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key, "Content-Type": content_type},
        data=data,
        timeout=120,
    )
    # If our session key expired, refresh once and retry
    if resp.status_code == 403:
        logger.info("storage 403 — re-initialising key and retrying")
        key = init_storage(force=True)
        resp = requests.put(
            f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key, "Content-Type": content_type},
            data=data,
            timeout=120,
        )
    resp.raise_for_status()
    return resp.json()


def get_object(path: str) -> Tuple[bytes, str]:
    """Download bytes by path. Returns (content_bytes, content_type)."""
    key = init_storage()
    resp = requests.get(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key},
        timeout=60,
    )
    if resp.status_code == 403:
        key = init_storage(force=True)
        resp = requests.get(
            f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key},
            timeout=60,
        )
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "application/octet-stream")


MIME_TYPES = {
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "png": "image/png",
    "webp": "image/webp",
    "pdf": "application/pdf",
}


def ext_for(content_type: str, filename: str = "") -> str:
    ct = (content_type or "").lower()
    if ct in ("image/jpeg", "image/jpg"):
        return "jpg"
    if ct == "image/png":
        return "png"
    if ct == "image/webp":
        return "webp"
    if ct == "application/pdf":
        return "pdf"
    if "." in filename:
        ext = filename.rsplit(".", 1)[-1].lower()
        if ext in MIME_TYPES:
            return ext
    return "bin"
