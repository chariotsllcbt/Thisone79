"""
Twilio SMS notification helper for Chariot.

DESIGNED TO BE DORMANT BY DEFAULT:
- If TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN / TWILIO_FROM_NUMBER are blank, every
  send is logged but no API call is made — the ride flow keeps working.
- When keys are added in /app/backend/.env and the backend is restarted,
  notifications start firing automatically. No code changes required.

Sends are always fire-and-forget: failures are logged and swallowed so an SMS
hiccup never breaks the ride pipeline.
"""
from __future__ import annotations

import asyncio
import logging
import os
from functools import lru_cache
from typing import Optional

logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def _client():
    sid = os.environ.get("TWILIO_ACCOUNT_SID", "").strip()
    token = os.environ.get("TWILIO_AUTH_TOKEN", "").strip()
    if not sid or not token:
        return None
    try:
        from twilio.rest import Client
        return Client(sid, token)
    except Exception as e:  # pragma: no cover - import / construction errors
        logger.warning(f"twilio client init failed: {e}")
        return None


def is_configured() -> bool:
    return bool(
        os.environ.get("TWILIO_ACCOUNT_SID", "").strip()
        and os.environ.get("TWILIO_AUTH_TOKEN", "").strip()
        and os.environ.get("TWILIO_FROM_NUMBER", "").strip()
    )


def _send_sync(to: str, body: str) -> Optional[str]:
    client = _client()
    if client is None:
        return None
    from_ = os.environ.get("TWILIO_FROM_NUMBER", "").strip()
    try:
        msg = client.messages.create(to=to, from_=from_, body=body)
        return msg.sid
    except Exception as e:
        logger.warning(f"twilio send failed to {to}: {e}")
        return None


async def send_sms(to: Optional[str], body: str) -> None:
    """Fire-and-forget SMS. Safe to await; never raises."""
    if not to:
        return
    to = to.strip()
    if not to:
        return
    if not is_configured():
        logger.info(f"[sms:dormant] would send to {to}: {body}")
        return
    try:
        sid = await asyncio.to_thread(_send_sync, to, body)
        if sid:
            logger.info(f"sms ok {to} sid={sid}")
    except Exception as e:
        logger.warning(f"sms task error to {to}: {e}")


def fire_and_forget(to: Optional[str], body: str) -> None:
    """Schedule an SMS without awaiting. Safe to call from any async path."""
    try:
        asyncio.create_task(send_sms(to, body))
    except RuntimeError:
        # No running loop — try a one-shot blocking call (rare in FastAPI).
        try:
            asyncio.run(send_sms(to, body))
        except Exception as e:
            logger.warning(f"sms fire-and-forget fallback failed: {e}")
